/**
 * command-palette — Ctrl+P 命令面板（纯状态机 + 渲染）。
 *
 * 数据源 = SlashCommandRegistry（getCommands 现取，插件扩展后可见）；
 * 过滤 = 名称/描述子串 + 名称子序列，前缀优先；状态机 open/type/backspace/move/close。
 */
import type { SlashCommand } from './commands/registry.js';
import type { RivetTheme } from './theme.js';
/** 面板条目：命令名（不含 `/` 前缀）+ 描述 + 可选参数提示。 */
export interface PaletteEntry {
    name: string;
    description: string;
    argsHint?: string;
}
/** 面板状态：开合 + 查询串 + 选中下标（指向过滤后列表）。 */
export interface PaletteState {
    open: boolean;
    query: string;
    selected: number;
}
/** 状态机输入事件（move 的 count = 过滤后可见条目数，由调用方计算）。 */
export type PaletteEvent = {
    type: 'open';
} | {
    type: 'close';
} | {
    type: 'type';
    char: string;
} | {
    type: 'backspace';
} | {
    type: 'move';
    delta: number;
    count: number;
};
/**
 * 初始面板状态（关闭、空查询、选中第 0 项）。
 * @returns 初始状态。
 */
export declare function emptyPaletteState(): PaletteState;
/**
 * SlashCommand → 面板条目。
 * @param commands - 注册表命令列表。
 * @returns 面板条目（argsHint 缺省时不带该字段）。
 */
export declare function toPaletteEntries(commands: readonly SlashCommand[]): PaletteEntry[];
/**
 * 模糊过滤：名称/描述子串 + 名称子序列；前缀优先排序；大小写不敏感。
 * @param entries - 全部条目。
 * @param query - 查询串（trim 后为空则返回全部）。
 * @returns 过滤排序后的条目。
 */
export declare function filterPalette(entries: readonly PaletteEntry[], query: string): PaletteEntry[];
/**
 * 过滤后可见条目（selected 指向过滤列表下标）。
 * @param state - 面板状态（取 query）。
 * @param entries - 全部条目。
 * @returns 过滤后条目。
 */
export declare function paletteVisibleEntries(state: PaletteState, entries: readonly PaletteEntry[]): PaletteEntry[];
/**
 * 折叠一个事件进入面板状态（纯函数）：open 重置查询与选中、type 追加字符并
 * 归零选中、move 在 [0, count-1] 内夹紧移动。
 * @param state - 当前状态。
 * @param event - 输入事件。
 * @returns 新状态。
 */
export declare function applyPaletteEvent(state: PaletteState, event: PaletteEvent): PaletteState;
/**
 * 回填文本：`/name `（含尾随空格，用户续写参数）。
 * @param entry - 选中条目。
 * @returns 回填到输入框的文本。
 */
export declare function paletteCommitText(entry: PaletteEntry): string;
/**
 * overlay 渲染：头 + 条目（选中 ▶ 高亮、宽度截断）+ 底部键位提示；滚动窗口跟随选中。
 * @param state - 面板状态。
 * @param entries - 全部条目（内部按 query 过滤）。
 * @param width - 可用显示宽度（条目按此截断）。
 * @param height - 可用行数（头尾各占一行，其余给条目窗口）。
 * @param theme - 主题（取语义色）。
 * @returns 渲染行数组（含 ANSI）。
 */
export declare function renderCommandPalette(state: PaletteState, entries: readonly PaletteEntry[], width: number, height: number, theme: RivetTheme): string[];
/** CommandPalette 构造选项（两个读取函数均动态现取）。 */
export interface CommandPaletteOptions {
    /** 命令列表读取函数（动态，插件扩展后新命令可见）。 */
    getCommands: () => readonly SlashCommand[];
    /** 主题读取函数（动态，切主题后 overlay 立即生效）。 */
    getTheme: () => RivetTheme;
}
/** Ctrl+P 面板控制器：open/toggle/type/move/commit，实现 OverlayRenderer 契约。 */
export declare class CommandPalette {
    private state;
    private readonly getCommands;
    private readonly getTheme;
    constructor(opts: CommandPaletteOptions);
    /**
     * 面板是否打开。
     * @returns 开合状态。
     */
    isOpen(): boolean;
    /** 打开面板（重置查询与选中）。 */
    open(): void;
    /** 关闭面板（保留查询，下次 open 时重置）。 */
    close(): void;
    /** 开合切换。 */
    toggle(): void;
    /**
     * 追加查询字符（选中归零）。
     * @param char - 输入字符。
     */
    type(char: string): void;
    /**
     * 移动选中项（在过滤后列表范围内夹紧）。
     * @param delta - 移动量（负上正下）。
     */
    move(delta: number): void;
    /** 当前查询串。 */
    get query(): string;
    /** 过滤后可见条目（paletteVisible 的别名访问器）。 */
    get entries(): PaletteEntry[];
    /**
     * 过滤后可见条目（命令现取自 getCommands）。
     * @returns 过滤后条目。
     */
    paletteVisible(): PaletteEntry[];
    /**
     * 提交选中项：返回条目 + 回填文本；无选中返回 null。
     * @returns 条目与回填文本；选中越界（如无匹配）返回 null。
     */
    commit(): {
        entry: PaletteEntry;
        text: string;
    } | null;
    /**
     * OverlayRenderer 契约：render(width, height) → string[]。
     * @param width - 可用显示宽度。
     * @param height - 可用行数。
     * @returns 渲染行数组（含 ANSI）。
     */
    render(width: number, height: number): string[];
}
