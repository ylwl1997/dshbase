/**
 * QuestionController — 挂起结构化提问状态机（Wave 1 从 ui/app.ts 提取）。
 *
 * 持有 pendingQuestion 挂起态（request + resolve/reject 句柄）与
 * questionFeedbackMode（plan-review 反馈输入态）。状态、行为、渲染三件事的
 * 对象边界：挂起/结算/取消收敛在本控制器，渲染经 peek() 快照由 renderLive
 * 消费，键仲裁由 app.ts handleKey 读 isPending/feedbackMode 后调 settle/cancel。
 *
 * 副作用注入（不 import app.ts、不碰渲染）：
 * - onEscapeImmediate(flag)：挂起期间 ESC 恒为「取消提问」而非 CSI 序列前缀，
 *   立即派发避免 80ms 窗口内后续按键被吞进序列缓冲（input-handler 语义）。
 * - onChanged()：状态实际变化（挂起/结算/取消）后回调，app 侧据此 flushLiveRender。
 *
 * 契约（与 user-questions provider 对齐）：
 * - 重叠 ask → reject UserQuestionError(ASK_CANCELLED)（一次只呈现一个问题）。
 * - cancel → reject UserQuestionError(ASK_CANCELLED)（取消必须 reject，非 resolve）。
 *
 * @module @deepseek-ai/dsh-tianshu-tui/controllers/question-controller
 */
import type { QuestionRequestInput } from '../question-panel.js';
/** 挂起态快照（renderLive 消费；无挂起时 peek() 返回 null）。 */
export interface QuestionPeek {
    /** 挂起中的提问请求（面板投影输入）。 */
    request: QuestionRequestInput;
    /** plan-review 反馈输入态（f 键进入；结算/取消时复位）。 */
    feedbackMode: boolean;
}
/** QuestionController 的副作用注入（不 import app.ts、不碰渲染）。 */
export interface QuestionControllerOptions {
    /** 挂起/解除挂起时同步切换 ESC 立即模式（保持挂起态 ESC 语义）。 */
    onEscapeImmediate: (flag: boolean) => void;
    /** 状态实际变化（挂起/结算/取消）后回调（app 侧触发重绘）。 */
    onChanged?: () => void;
}
/**
 * 挂起结构化提问状态机：一次只挂起一个问题（重叠 ask 即 reject），
 * settle/cancel 结算句柄，peek() 给 renderLive 出快照（见模块注释契约）。
 */
export declare class QuestionController {
    private pending;
    private feedback;
    private readonly onEscapeImmediate;
    private readonly onChanged;
    constructor(options: QuestionControllerOptions);
    /** 是否有挂起的提问（handleKey 分支入口判断）。 */
    get isPending(): boolean;
    /** plan-review 反馈输入态（f 键进入；结算/取消时复位）。 */
    get feedbackMode(): boolean;
    /**
     * 进入/退出反馈输入态（f 键 / Esc 返回选项态；不触发结算）。
     * @param flag - true 进入反馈输入态，false 返回选项态。
     */
    setFeedbackMode(flag: boolean): void;
    /**
     * 挂起一个提问请求：存 resolve/reject 句柄，返回等用户结算的 promise。
     * 已有挂起时 reject ASK_CANCELLED（重叠保护，不覆盖首个挂起）。
     * @param request - user-questions 的 AskUserQuestionRequest 形状（cast 自 unknown）。
     * @returns 结算值（settle 的 answer）或 UserQuestionError(ASK_CANCELLED)。
     */
    ask(request: unknown): Promise<unknown>;
    /**
     * 结算挂起的提问（用户选择/提交反馈）。
     * @param answer - provider 契约的结算值（{ answers: [{ id, selected[], custom? }] }）。
     */
    settle(answer: unknown): void;
    /**
     * 取消挂起的提问（Esc/Ctrl+C）——reject ASK_CANCELLED（provider 契约）。
     */
    cancel(): void;
    /**
     * 当前挂起态快照（renderLive 挂起段消费）。
     * @returns { request, feedbackMode }；无挂起 null。
     */
    peek(): QuestionPeek | null;
}
