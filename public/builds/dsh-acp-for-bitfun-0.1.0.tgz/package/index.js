/**
 * dsh-acp-for-bitfun: connect DeepSeek Harness (dsh) to the BitFun agent
 * (https://github.com/GCWing/BitFun) over the Agent Client Protocol.
 *
 * BitFun ships an ACP server at `bitfun acp` (Agent Client Protocol v1 over
 * stdio). This bundle registers a `bitfun` subagent provider backed by
 * `@deepseek-ai/dsh-subagent-acp` (one fresh `bitfun acp` child per run) and
 * mounts a model-facing `subagent_bitfun` tool through
 * `@deepseek-ai/dsh-tool-subagent`, so any dsh session can delegate work to
 * BitFun.
 *
 * Named exports only: a default export would hide loader metadata.
 * @module dsh-acp-for-bitfun
 */

import { spawnSync } from 'node:child_process'
import Schema from '@deepseek-ai/schemastery'
import * as subagentAcp from '@deepseek-ai/dsh-subagent-acp'
import * as toolSubagent from '@deepseek-ai/dsh-tool-subagent'

export const name = 'bitfun-acp'

/**
 * Config: how to find the BitFun CLI and expose it to the model.
 *
 * @typedef {object} Config
 * @property {string} command - the BitFun CLI executable: a bare name resolved
 *   on PATH (default `bitfun`) or an absolute path. BitFun ACP works through
 *   `bitfun acp`.
 * @property {string} providerName - provider name on `ctx.subagents` (default
 *   `bitfun`).
 * @property {string} toolName - model-facing tool name (default
 *   `subagent_bitfun`).
 * @property {'allow' | 'reject'} permission - how to auto-answer BitFun's
 *   `session/request_permission` prompts.
 * @property {string[]} acpArgs - extra arguments appended after `command` when
 *   spawning `bitfun acp`.
 * @property {Record<string, string>} env - extra environment for the BitFun
 *   child process.
 * @property {boolean} checkOnStart - probe `command --version` at load and fail
 *   loudly when the BitFun CLI is missing, instead of failing on the first
 *   delegation (default true).
 */

export const Config = Schema.object({
  command: Schema.string().default('bitfun'),
  providerName: Schema.string().default('bitfun'),
  toolName: Schema.string().default('subagent_bitfun'),
  permission: Schema.union(['allow', 'reject']).default('reject'),
  acpArgs: Schema.array(Schema.string()).default(['acp']),
  env: Schema.dict(Schema.string()).default({}),
  checkOnStart: Schema.boolean().default(true),
})

/**
 * Resolve the BitFun CLI before any provider or tool mounts so a missing
 * install fails during profile boot, not on the first delegation.
 * @param command - the configured executable (bare name or absolute path).
 * @returns the probe result.
 */
function probeBitfun(command) {
  const probe = spawnSync(command, ['--version'], { stdio: ['ignore', 'pipe', 'pipe'] })
  if (probe.error !== undefined) {
    return { ok: false, detail: probe.error.message }
  }
  if (probe.status !== 0) {
    const detail = probe.stderr.toString().trim() || `exit code ${probe.status}`
    return { ok: false, detail }
  }
  return { ok: true, detail: probe.stdout.toString().trim() }
}

export function apply(ctx, config) {
  if (config.checkOnStart) {
    const probe = probeBitfun(config.command)
    if (!probe.ok) {
      throw new Error(
        `bitfun-acp: BitFun CLI not usable via "${config.command}" (${probe.detail}). `
        + 'Install BitFun from https://github.com/GCWing/BitFun, verify with `bitfun acp doctor`, '
        + 'or set `command` to the absolute path of the bitfun executable.',
      )
    }
    ctx.logger.info(`bitfun-acp: BitFun CLI ready (${probe.detail})`)
  }

  // Register the ACP provider on ctx.subagents. Config is passed fully
  // resolved because a direct plugin load does not run the Schemastery
  // defaults of the upstream plugin.
  ctx.logger.info(`bitfun-acp: registering provider "${config.providerName}" via ${subagentAcp.name}`)
  ctx.plugin(subagentAcp, {
    providerName: config.providerName,
    command: config.command,
    args: config.acpArgs,
    permission: config.permission,
    env: config.env,
    disposeEofGraceMs: 6000,
    disposeGraceMs: 3000,
  })

  // Mount the model-facing delegation tool over the provider above. The
  // out-of-process BitFun child owns its recursion budget, so the cap is
  // provider-managed.
  ctx.plugin(toolSubagent, {
    provider: config.providerName,
    toolName: config.toolName,
    maxDepth: 'provider-managed',
    enableRunInBackground: true,
    backgroundMode: 'one-shot',
  })
}
