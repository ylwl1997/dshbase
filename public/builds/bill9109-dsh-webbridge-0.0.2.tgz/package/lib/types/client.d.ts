/**
 * Kimi WebBridge daemon client: one POST /command call per browser action.
 *
 * The daemon lives at `http://127.0.0.1:10086` (installed by
 * `curl -fsSL https://cdn.kimi.com/webbridge/install.sh | bash`). Every
 * request carries a top-level `session` naming the current task; tabs opened
 * under one session form one browser tab group. The daemon answers
 * `{ok:true, data}` on success and `{ok:false, error:{code,message}}` on
 * failure (extension not connected, unknown action, page errors, ...).
 *
 * @module @deepseek-ai/dsh-webbridge
 */
/** Daemon base URL; overridable for tests. */
export declare const WEBBRIDGE_DEFAULT_URL = "http://127.0.0.1:10086";
/** One browser-control command understood by the daemon. */
export type WebBridgeAction = 'navigate' | 'find_tab' | 'snapshot' | 'click' | 'fill' | 'evaluate' | 'screenshot' | 'network' | 'upload' | 'save_as_pdf' | 'list_tabs' | 'close_tab' | 'close_session';
/** A rejected daemon call. */
export declare class WebBridgeError extends Error {
    readonly code: string;
    readonly action: WebBridgeAction;
    constructor(message: string, code: string, action: WebBridgeAction);
}
/** Successful daemon payload (`data` is action-specific). */
export interface WebBridgeOk {
    ok: true;
    data: Record<string, unknown>;
}
/** Rejected daemon payload. */
export interface WebBridgeFail {
    ok: false;
    error: {
        code: string;
        message: string;
    };
}
/** One daemon call result. */
export type WebBridgeResult = WebBridgeOk | WebBridgeFail;
/**
 * Call the daemon once. Throws {@link WebBridgeError} on transport failure
 * (daemon down) and returns the daemon's own rejection verbatim as a
 * {@link WebBridgeFail} — the caller decides how to surface either.
 */
export declare function webbridgeCommand(action: WebBridgeAction, args: Record<string, unknown>, session: string, baseUrl?: string): Promise<WebBridgeResult>;
