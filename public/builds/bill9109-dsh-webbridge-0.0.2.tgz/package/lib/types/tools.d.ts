/**
 * Kimi WebBridge model tools: browser control through the local daemon.
 *
 * Every tool talks to `127.0.0.1:10086` (the kimi-webbridge daemon), which
 * drives the user's REAL browser (their login sessions included) through the
 * WebBridge extension. Tools cover navigation, page reading (accessibility
 * tree snapshot), interaction (click/fill), JS evaluation, screenshots, and
 * tab management. A single `webbridge_session` parameter names the current
 * task on every call — tabs opened under one session form one tab group.
 *
 * @module @deepseek-ai/dsh-webbridge
 */
/** Registry-ready tool set. `baseUrl` overrides the daemon address (tests). */
export declare function webbridgeTools(baseUrl?: string): {
    navigate: import("@deepseek-ai/dsh-tools").ToolDefinition;
    findTab: import("@deepseek-ai/dsh-tools").ToolDefinition;
    snapshot: import("@deepseek-ai/dsh-tools").ToolDefinition;
    click: import("@deepseek-ai/dsh-tools").ToolDefinition;
    fill: import("@deepseek-ai/dsh-tools").ToolDefinition;
    evaluate: import("@deepseek-ai/dsh-tools").ToolDefinition;
    screenshot: import("@deepseek-ai/dsh-tools").ToolDefinition;
    listTabs: import("@deepseek-ai/dsh-tools").ToolDefinition;
    network: import("@deepseek-ai/dsh-tools").ToolDefinition;
    closeTab: import("@deepseek-ai/dsh-tools").ToolDefinition;
    closeSession: import("@deepseek-ai/dsh-tools").ToolDefinition;
};
