/**
 * Kimi WebBridge daemon client: one POST /command call per browser action.
 *
 * The daemon lives at `http://127.0.0.1:10086` (installed by
 * `curl -fsSL https://cdn.kimi.com/webbridge/install.sh | bash`). Every
 * request carries a top-level `session` naming the current task; tabs opened
 * under one session form one browser tab group. The daemon answers
 * `{ok:true, data}` on success and `{ok:false, error:{code,message}}` on
 * failure (extension not connected, unknown action, page errors, ...).
 *
 * @module @deepseek-ai/dsh-webbridge
 */

/** Daemon base URL; overridable for tests. */
export const WEBBRIDGE_DEFAULT_URL = 'http://127.0.0.1:10086'

/** One browser-control command understood by the daemon. */
export type WebBridgeAction =
  | 'navigate'
  | 'find_tab'
  | 'snapshot'
  | 'click'
  | 'fill'
  | 'evaluate'
  | 'screenshot'
  | 'network'
  | 'upload'
  | 'save_as_pdf'
  | 'list_tabs'
  | 'close_tab'
  | 'close_session'

/** A rejected daemon call. */
export class WebBridgeError extends Error {
  constructor(
    message: string,
    readonly code: string,
    readonly action: WebBridgeAction,
  ) {
    super(message)
    this.name = 'WebBridgeError'
  }
}

/** Successful daemon payload (`data` is action-specific). */
export interface WebBridgeOk {
  ok: true
  data: Record<string, unknown>
}

/** Rejected daemon payload. */
export interface WebBridgeFail {
  ok: false
  error: { code: string; message: string }
}

/** One daemon call result. */
export type WebBridgeResult = WebBridgeOk | WebBridgeFail

/**
 * Call the daemon once. Throws {@link WebBridgeError} on transport failure
 * (daemon down) and returns the daemon's own rejection verbatim as a
 * {@link WebBridgeFail} — the caller decides how to surface either.
 */
export async function webbridgeCommand(
  action: WebBridgeAction,
  args: Record<string, unknown>,
  session: string,
  baseUrl = WEBBRIDGE_DEFAULT_URL,
): Promise<WebBridgeResult> {
  let response: Response
  try {
    response = await fetch(`${baseUrl}/command`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ action, args, session }),
      // Browser control should not hang forever; the daemon is local.
      signal: AbortSignal.timeout(30_000),
    })
  } catch (error) {
    throw new WebBridgeError(
      `kimi-webbridge daemon unreachable at ${baseUrl} (start it with ~/.kimi-webbridge/bin/kimi-webbridge start): ${error instanceof Error ? error.message : String(error)}`,
      'daemon_unreachable',
      action,
    )
  }
  if (!response.ok) {
    throw new WebBridgeError(
      `kimi-webbridge daemon returned HTTP ${response.status}`,
      'http_error',
      action,
    )
  }
  const body = (await response.json()) as WebBridgeResult
  if (body.ok) return body
  throw new WebBridgeError(
    body.error.message,
    body.error.code,
    action,
  )
}
