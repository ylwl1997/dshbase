/**
 * Kimi WebBridge model tools: browser control through the local daemon.
 *
 * Every tool talks to `127.0.0.1:10086` (the kimi-webbridge daemon), which
 * drives the user's REAL browser (their login sessions included) through the
 * WebBridge extension. Tools cover navigation, page reading (accessibility
 * tree snapshot), interaction (click/fill), JS evaluation, screenshots, and
 * tab management. A single `webbridge_session` parameter names the current
 * task on every call — tabs opened under one session form one tab group.
 *
 * @module @deepseek-ai/dsh-webbridge
 */

import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { JsonValue } from '@deepseek-ai/dsh-session'
import { webbridgeCommand, WEBBRIDGE_DEFAULT_URL } from './client.ts'
import type { WebBridgeAction } from './client.ts'

/** Session label the model passes with every call (one task = one group). */
const SESSION_ARG = {
  session: {
    type: 'string',
    required: true,
    description: [
      'Task/session name: one task = one name, kept constant across ALL calls of the',
      'task (never switch mid-task — that fragments tab groups). Name it after the',
      'task, not the site (e.g. "camping-research"). Tabs opened under one session',
      'form one browser tab group. On the first navigate of a task, tell the user',
      'once that the task\'s pages are collected under the group\'s visible label, and',
      'that you will close them whenever they ask.',
    ].join(' '),
  },
} as const

/** One tool result as a lossless-JSON value (what the model receives). */
interface ToolResultValue {
  ok: boolean
  summary: string
  detail: JsonValue
}

/** Shared output: the daemon's raw JSON payload plus a readable summary. */
const RAW_OUTPUT = {
  schema: {
    type: 'object',
    additionalProperties: false,
    properties: {
      ok: { type: 'boolean' },
      summary: { type: 'string' },
      detail: { type: 'json' },
    },
  },
  render: (_args: unknown, value: ToolResultValue): ContentBlock[] => [{
    type: 'text',
    text: value.summary,
  }],
} as const

/** Shared call presentation: a generic card with the action + URL. */
function present(title: string): (_args: Record<string, unknown>) => { card: 'generic'; title: string; kind: 'other'; rawInput: Record<string, unknown> } {
  return args => ({ card: 'generic', title, kind: 'other', rawInput: args })
}

/** Run one daemon action and fold the result into the shared output shape. */
async function run(
  action: WebBridgeAction,
  args: Record<string, unknown>,
  session: string,
  baseUrl: string,
): Promise<ToolResultValue> {
  const result = await webbridgeCommand(action, args, session, baseUrl)
  if (!result.ok) return { ok: false, summary: 'browser action failed', detail: {} }
  const data = result.data
  const summary = compactSummary(data)
  return { ok: true, summary, detail: data as JsonValue }
}

/** Build a compact one-line summary from an action payload. */
function compactSummary(data: Record<string, unknown>): string {
  const parts: string[] = []
  for (const key of ['url', 'title', 'success', 'tabId', 'mode', 'format', 'sizeBytes', 'type']) {
    const value = data[key]
    if (value !== undefined && value !== null) parts.push(`${key}=${typeof value === 'object' ? JSON.stringify(value) : String(value)}`)
  }
  if (parts.length > 0) return parts.join(' ')
  const text = JSON.stringify(data)
  return text.length > 200 ? `${text.slice(0, 200)}…` : text
}

/** Registry-ready tool set. `baseUrl` overrides the daemon address (tests). */
export function webbridgeTools(baseUrl = WEBBRIDGE_DEFAULT_URL) {
  const navigate = defineTool({
    name: 'webbridge_navigate',
    description: [
      'Open a URL in the user\'s real browser (their login sessions included) and make',
      'that tab the current one. Use newTab=true when pages should coexist; omit it to',
      'send the current tab to a new URL. group_title sets the tab group\'s visible',
      'label (write it in the user\'s language).',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      url: { type: 'string', required: true, description: 'Full URL to open (https://…).' },
      newTab: { type: 'boolean', description: 'Open in a new tab (default false).' },
      group_title: { type: 'string', description: 'Human-readable label for the tab group, set on the first navigate of a task.' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Open in browser'),
    execute: async args => run('navigate', {
      url: String(args.url),
      ...(args.newTab === true ? { newTab: true } : {}),
      ...(typeof args.group_title === 'string' && args.group_title !== '' ? { group_title: args.group_title } : {}),
    }, String(args.session), baseUrl),
  })

  const findTab = defineTool({
    name: 'webbridge_find_tab',
    description: [
      'Re-select a tab this task opened (or, with active=true, borrow the tab the user',
      'is currently viewing). Pass the tab\'s full URL from list_tabs or the earlier',
      'navigate result. Prefer this over opening a duplicate when the page may',
      'already be open in this session.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      url: { type: 'string', required: true, description: 'Full URL of the tab to select.' },
      active: { type: 'boolean', description: 'Borrow the tab the user is currently viewing (default false).' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Select browser tab'),
    execute: async args => run('find_tab', {
      url: String(args.url),
      ...(args.active === true ? { active: true } : {}),
    }, String(args.session), baseUrl),
  })

  const snapshot = defineTool({
    name: 'webbridge_snapshot',
    description: [
      'Read the current page\'s accessibility tree (interactive elements with @e refs,',
      'text content, headings, links, buttons). Use this to understand what is on the',
      'page and to locate elements for click/fill. Prefer this over CSS selectors:',
      '@e refs survive CSS class hash changes.',
    ].join(' '),
    parameters: { ...SESSION_ARG },
    output: RAW_OUTPUT,
    presentCall: present('Snapshot page'),
    execute: async args => run('snapshot', {}, String(args.session), baseUrl),
  })

  const click = defineTool({
    name: 'webbridge_click',
    description: [
      'Click an element on the current page. Pass the @e ref from snapshot (e.g. @e12)',
      'or a CSS selector. Fires a DOM-level synthetic click — sites that strictly',
      'check event.isTrusted (banking portals, captchas) may ignore it.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      selector: { type: 'string', required: true, description: '@e ref from snapshot or a CSS selector.' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Click element'),
    execute: async args => run('click', { selector: String(args.selector) }, String(args.session), baseUrl),
  })

  const fill = defineTool({
    name: 'webbridge_fill',
    description: [
      'Type into an input, textarea, or contenteditable rich editor (ProseMirror,',
      'TipTap, Lexical, Slate, Quill). Clear-and-insert: existing content is',
      'replaced. To append, read the current value via evaluate first.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      selector: { type: 'string', required: true, description: '@e ref from snapshot or a CSS selector.' },
      value: { type: 'string', required: true, description: 'Text to insert.' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Fill input'),
    execute: async args => run('fill', { selector: String(args.selector), value: String(args.value) }, String(args.session), baseUrl),
  })

  const evaluate = defineTool({
    name: 'webbridge_evaluate',
    description: [
      'Run JavaScript in the current page (async/await supported). Use for reading',
      'attributes, dispatching complex event sequences, or scrolling. Wrap',
      're-declarations in an IIFE — evaluate calls share the page\'s JS realm.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      code: { type: 'string', required: true, description: 'JavaScript expression to evaluate (compact, no formatting whitespace).' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Evaluate JS'),
    execute: async args => run('evaluate', { code: String(args.code) }, String(args.session), baseUrl),
  })

  const screenshot = defineTool({
    name: 'webbridge_screenshot',
    description: [
      'Screenshot the current page (or one element via selector). Returns a file',
      'path on disk — read the file to see the image. Use for visual verification',
      'of the current browser state.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      format: { type: 'string', description: 'png (default) or jpeg.' },
      quality: { type: 'integer', description: 'JPEG quality 0-100 (default 80).' },
      selector: { type: 'string', description: '@e ref or CSS selector to capture just that element.' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Screenshot page'),
    execute: async args => run('screenshot', {
      ...(typeof args.format === 'string' ? { format: args.format } : {}),
      ...(typeof args.quality === 'number' ? { quality: args.quality } : {}),
      ...(typeof args.selector === 'string' && args.selector !== '' ? { selector: args.selector } : {}),
    }, String(args.session), baseUrl),
  })

  const listTabs = defineTool({
    name: 'webbridge_list_tabs',
    description: 'List the tabs opened in this task session (tabId, url, title, active).',
    parameters: { ...SESSION_ARG },
    output: RAW_OUTPUT,
    presentCall: present('List session tabs'),
    execute: async args => run('list_tabs', {}, String(args.session), baseUrl),
  })

  const network = defineTool({
    name: 'webbridge_network',
    description: [
      'Inspect network activity of the current page: start/stop capturing, list',
      'captured requests, or get request/response detail by requestId. Use for',
      'debugging API calls and verifying page behavior.',
    ].join(' '),
    parameters: {
      ...SESSION_ARG,
      cmd: { type: 'string', required: true, description: 'start | stop | list | detail.' },
      filter: { type: 'string', description: 'URL filter for start/list.' },
      requestId: { type: 'string', description: 'requestId for detail.' },
    },
    output: RAW_OUTPUT,
    presentCall: present('Inspect network'),
    execute: async args => run('network', {
      cmd: String(args.cmd),
      ...(typeof args.filter === 'string' && args.filter !== '' ? { filter: args.filter } : {}),
      ...(typeof args.requestId === 'string' && args.requestId !== '' ? { requestId: args.requestId } : {}),
    }, String(args.session), baseUrl),
  })

  const closeTab = defineTool({
    name: 'webbridge_close_tab',
    description: 'Close the current tab of this task session.',
    parameters: { ...SESSION_ARG },
    output: RAW_OUTPUT,
    presentCall: present('Close session tab'),
    execute: async args => run('close_tab', {}, String(args.session), baseUrl),
  })

  const closeSession = defineTool({
    name: 'webbridge_close_session',
    description: [
      'Close ALL tabs of this task session (one call clears the whole tab group).',
      'CLOSING IS USER-INITIATED: call this ONLY when the user explicitly asks to',
      'close/clear the tabs ("close those", "clear the tabs"). Never close tabs',
      'automatically at the end of a task — the user decides when to dismiss them.',
    ].join(' '),
    parameters: { ...SESSION_ARG },
    output: RAW_OUTPUT,
    presentCall: present('Close task tab group'),
    execute: async args => run('close_session', {}, String(args.session), baseUrl),
  })

  return { navigate, findTab, snapshot, click, fill, evaluate, screenshot, listTabs, network, closeTab, closeSession }
}
