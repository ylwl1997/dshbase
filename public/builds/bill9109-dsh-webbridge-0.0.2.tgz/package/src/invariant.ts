/** dsh-webbridge invariant helpers. */
export function invariant(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`dsh-webbridge: ${message}`)
}
