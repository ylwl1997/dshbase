/**
 * dsh-webbridge host plugin: registers the Kimi WebBridge model tools
 * (browser control through the local kimi-webbridge daemon).
 *
 * The daemon is installed independently (`curl -fsSL
 * https://cdn.kimi.com/webbridge/install.sh | bash`) and runs at
 * `http://127.0.0.1:10086`. The plugin surfaces it to the model as
 * `webbridge_*` tools; every call names a session (task), and the user's
 * real browser (with their logins) is the controlled surface.
 *
 * @module @deepseek-ai/dsh-webbridge
 */

import type { Context } from 'cordis'
import type {} from '@deepseek-ai/dsh-tools'
import { webbridgeTools } from './tools.ts'

/** Stable plugin name used by loader diagnostics. */
export const name = 'dsh-webbridge'

/** Services required by the plugin. */
export const inject = ['tools']

/**
 * Mount the plugin.
 * @param ctx - host root context.
 */
export function apply(ctx: Context): void {
  const tools = webbridgeTools()
  for (const tool of Object.values(tools)) {
    ctx.effect(
      () => ctx.tools.register(tool),
      `dsh-webbridge: register ${tool.name}`,
    )
  }
}
