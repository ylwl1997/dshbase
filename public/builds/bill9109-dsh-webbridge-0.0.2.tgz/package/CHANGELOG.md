# Changelog

All notable user-facing changes to dsh-webbridge are documented in this file. The project follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and uses semantic version tags.

## [Unreleased]

## [0.0.2] - 2026-08-14

### Changed

- Repositioned the README around the project's role as a DeepSeek Harness host plugin bridging Kimi WebBridge, in the shared bilingual convention: `README.md` (English) is now the main file, `README.zh.md` carries the Chinese side, and `README.i18n.yaml` records their git blob hashes with a `scripts/verify-i18n.mjs` consistency check.
- Added versioned static badges, a one-line install command, and sections for Why this exists, Usage, Upgrade/Uninstall lifecycle, Troubleshooting, and Development and verification.
- Expanded `package.json` metadata: English description, `keywords`, `engines`, the `./cordis.patch.yml` export, and README files in `files`.
- Added `CHANGELOG.md`, `CONTRIBUTING.md`, `SECURITY.md`, `SUPPORT.md`, and `CODE_OF_CONDUCT.md`.

## [0.0.1] - 2026-08-14

### Added

- Initial release: a DeepSeek Harness host plugin that bridges the local kimi-webbridge daemon into eleven `webbridge_*` model tools (navigate / find_tab / snapshot / click / fill / evaluate / screenshot / list_tabs / network / close_tab / close_session), letting the model drive the user's real browser while browser state stays on the machine.
- Declared as a DSH bundle (`dsh.bundle` + `cordis.patch.yml`) with the row id `webbridge`, which overrides the built-in plugin of the same row id when installed.
- Committed `lib/` build output so git installs work without a build step; unit tests (`tests/client.spec.ts`) run against a mock HTTP daemon, with live-daemon integration tests behind `KIMI_WEBBRIDGE_IT=1`.

### Changed

- Renamed the package scope `@dsh-external` → `@bill9109` (repositories live under `github.com/bill9109`); the built `lib/` was rebuilt with the new registration name.
