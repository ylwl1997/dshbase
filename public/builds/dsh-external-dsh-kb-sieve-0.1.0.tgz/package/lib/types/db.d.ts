/**
 * SQLite schema + build-time write path — faithful port of the Python
 * `db/schema.py` + `db/crud.py`. Whole-document mode: `docs` (tokenized body)
 * + external-content FTS5 `doc_fts` (fts_title, body) + `line_offsets`.
 *
 * @module @dsh-external/dsh-kb-sieve/db
 */
import { DatabaseSync } from 'node:sqlite';
export interface DocRecord {
    docId: string;
    docTitle: string;
    sourceFile: string;
    sourcePath: string;
    docHash: string;
    sourceVersion: string;
    isActive: boolean;
    /** Pre-tokenized FTS body (space-joined tokens). */
    body: string;
    /** FULL doc.md text — the line-number base (physical doc.md lines). */
    bodyText: string;
    /** Original document line count (density short-doc branch semantics). */
    canonicalLineCount: number;
}
/** Whether the pack has the line-level secondary index (new packs).
 * Keyed on line_text (the table the query/read paths actually read) so a
 * half-corrupt pack behaves identically in kb_query and kb_read. */
export declare function hasLineIndex(conn: DatabaseSync): boolean;
/** Open a kb.sqlite for writing (schema + pragmas applied). */
export declare function openKbForWrite(dbPath: string): DatabaseSync;
/** Delete ALL versions of one document's live rows (docs/doc_fts/line_text/
 * line_rowmap). The doc_id is single-version in this pack model: a source
 * title version change (V1→V2) must not leave stale rows of the old version
 * (they would collide on line numbers and surface as duplicate matches).
 *
 * line_fts rows are KEPT as orphans: the rowmap no longer points at them, so
 * density JOINs and line matching (line_text) are unaffected; a full rebuild
 * (force) reclaims the index space. FTS5 row-at-a-time DELETE is far slower
 * than inserting the new rows, hence the orphan design. */
export declare function deleteDoc(conn: DatabaseSync, docId: string): void;
/** Insert one document's rows (line index + docs + doc_fts), committing in
 * batches of 50K rows so WAL/journal memory stays bounded on huge docs.
 * Every line gets a line_fts row and a line_rowmap entry (explicit
 * rowid→(doc_id, line_number) mapping, robust to incremental deletes). */
/** Slice offset for a chunk boundary: keep the trailing chunk complete unless
 * the remainder is exhausted (avoids splitting mid-line numbering). */
export declare function writeDoc(conn: DatabaseSync, d: DocRecord): void;
/** Finalize a write session: indexes + FTS optimize (call once per build). */
export declare function finalizeKb(conn: DatabaseSync): void;
//# sourceMappingURL=db.d.ts.map