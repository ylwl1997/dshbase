/**
 * Shared index-layout version (single source of truth).
 *
 * Bumped whenever the on-disk index layout changes such that old packs must
 * be rebuilt before their data is trustworthy:
 *   3 — line_text has is_heading (heading rows materialized at build time;
 *       section maps are index point-reads, no SQL regex approximation)
 *   2 — line_text has text_lower AND line numbers are physical doc.md lines
 *       (full doc.md, frontmatter included).
 *
 * build.ts rebuilds packs whose build_state.index_version is older; query.ts
 * and read.ts attach a warning when serving such packs.
 *
 * @module @dsh-external/dsh-kb-sieve/constants
 */
export declare const INDEX_VERSION = 3;
//# sourceMappingURL=constants.d.ts.map