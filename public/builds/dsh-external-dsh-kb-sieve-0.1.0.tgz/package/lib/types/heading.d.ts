/**
 * Heading detection — the SINGLE source of truth for what counts as a
 * section heading line.
 *
 * The decision is materialized at build time (line_text.is_heading), so
 * query-time section maps are index point-reads (`WHERE is_heading = 1`)
 * instead of scanning every line with a SQL approximation of a JS regex.
 * The legacy file path (index-less packs) uses the same function, so both
 * paths agree line-for-line by construction.
 *
 * @module @dsh-external/dsh-kb-sieve/heading
 */
/** Whether a line is a section heading. Leading whitespace is stripped
 * first (trim() semantics: any JS whitespace), matching how both the
 * indexed and legacy paths have always classified lines. */
export declare function isHeadingLine(text: string): boolean;
//# sourceMappingURL=heading.d.ts.map