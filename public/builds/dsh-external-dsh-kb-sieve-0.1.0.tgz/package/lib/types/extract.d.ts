/**
 * Document extraction — faithful port of the Python `extract.py`.
 *
 * `.md` verbatim; `.txt`/`.pdf` text gets heading inference (underline,
 * Chapter/第X章, numbered, short-line heuristics); `.docx` parses OOXML
 * `w:p`/`w:t` paragraphs with Heading1-6 styles (zip via fflate); `.pdf`
 * requires the system `pdftotext` (poppler-utils), mirroring the original.
 *
 * @module @dsh-external/dsh-kb-sieve/extract
 */
export declare class BuildError extends Error {
}
/**
 * Detect text encoding by fatal-decode cascade: utf-8-sig → utf-8 → gb18030 →
 * cp1252 → latin-1 (TextDecoder is non-fatal by default, so each step must
 * pass `fatal: true` or the cascade would silently accept mojibake).
 */
export declare function detectAndDecode(data: Uint8Array): string;
/** Infer markdown headings from plain text (underline + short-line/numbered heuristics). */
export declare function inferTextHeadingsToMarkdown(text: string): string;
/** Extract any supported input to markdown. */
export declare function extractToMarkdown(path: string): Promise<string>;
//# sourceMappingURL=extract.d.ts.map