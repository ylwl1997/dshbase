/**
 * Build orchestration — port of the Python `build.py` core path (whole-doc,
 * non-incremental). Produces an auditable knowledge pack:
 *
 *   <pack>/SKILL.md  <pack>/manifest.json  <pack>/kb.sqlite
 *   <pack>/references/<doc_id>/{doc.md, metadata.md, structure_report.json}
 *
 * @module @dsh-external/dsh-kb-sieve/build
 */
/** NFKC + LF normalization + trailing newline (canonical text). */
export declare function normalizeCanonicalText(text: string): string;
export interface BuiltDoc {
    docId: string;
    title: string;
    sourceFile: string;
    sourcePath: string;
    docHash: string;
    sourceVersion: string;
    canonical: string;
    /** doc.md body (frontmatter stripped) — the exact text kb_read reads, so
     *  the line index and read-engine line numbers stay aligned. */
    bodyText: string;
}
export interface BuildResult {
    skillRoot: string;
    skillName: string;
    title: string;
    docCount: number;
    docIds: string[];
    errors: string[];
    generatedAt: string;
}
export interface BuildOptions {
    skillName: string;
    title: string;
    inputs: string[];
    outDir: string;
    /** true: incremental when a compatible build_state exists (default); false: full rebuild. */
    force: boolean;
    /** Extraction concurrency (default 4, capped 8) — bounds peak memory. */
    workers?: number;
}
export interface BuildResult {
    skillRoot: string;
    skillName: string;
    title: string;
    docCount: number;
    docIds: string[];
    errors: string[];
    generatedAt: string;
    /** Incremental statistics (full builds: everything counts as 'added'). */
    stats: {
        unchanged: number;
        changed: number;
        added: number;
        removed: number;
        failed: number;
    };
}
/**
 * Build (or incrementally update) a knowledge pack.
 *
 * Pipeline: doc_ids are assigned in input order (deterministic across runs);
 * extraction runs with bounded concurrency; each document is written
 * (references + SQLite rows) as soon as it finishes and its text is released
 * immediately, so peak memory ≈ workers × one document's text — no
 * whole-corpus accumulation.
 *
 * Incremental (when a compatible build_state.json exists and force=false):
 * - unchanged:  source bytes fingerprint matches → skipped entirely
 * - changed:    re-extracted and rewritten (deleteDoc + writeDoc)
 * - new:        inserted
 * - removed:    inputs no longer contain a previously indexed path → deleteDoc
 * The kb.sqlite copy is updated in a temp file and atomically renamed back.
 */
export declare function buildSkill(opts: BuildOptions): Promise<BuildResult>;
//# sourceMappingURL=build.d.ts.map