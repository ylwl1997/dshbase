/**
 * Canonical tokenization core — faithful TS port of the original Python
 * `tokenizer_core.py` (the SINGLE source of truth for both build-time
 * indexing and runtime query tokenization in the Python kb-sieve).
 *
 * CJK runs → overlapping 2/3/4-grams (+ full word for 2-6 char runs); ASCII
 * words `[A-Za-z0-9_]{2,}` lowercased; full-width punctuation mapped to
 * ASCII before tokenization; CJK/EN stop words filtered at query time.
 *
 * @module @dsh-external/dsh-kb-sieve/tokenizer
 */
/** Whether *ch* is a CJK unified or compatibility ideograph. */
export declare function isCjk(ch: string): boolean;
/** Tokenize a CJK run into full word (2-6) + deduplicated overlapping 2/3/4-grams. */
export declare function tokenizeCjkNgram(text: string): string[];
/** Full tokenization: punctuation normalization + CJK ngrams + ASCII words, minus stop words. */
export declare function ftsTokens(text: string): string[];
/** OR of quoted tokens (default query). */
export declare function buildMatchQuery(tokens: readonly string[], maxTokens?: number): string;
/** AND of quoted tokens (per-term must-match). */
export declare function buildMatchAll(tokens: readonly string[], maxTokens?: number): string;
/** Split a raw query into whitespace-separated parts. */
export declare function queryTerms(rawQuery: string): string[];
/** Build a full MATCH expression: optional must-terms + query mode (and/or). */
export declare function buildMatchExpression(rawQuery: string, opts: {
    queryMode: string;
    mustTerms: readonly string[];
    maxTokens?: number;
}): string;
/** Markdown → plain text (headings, inline code, links, emphasis stripped). */
export declare function markdownToPlain(md: string): string;
/** Parse YAML frontmatter (line-level; robust to '---' inside values). */
export declare function parseFrontmatter(md: string): Record<string, string>;
/** Strip YAML frontmatter (line-start `---` only; keeps line structure). */
export declare function stripFrontmatter(md: string): string;
/** SHA-256 hex digest (64 chars). */
export declare function stableHash(text: string): string;
/** Derive source_version from a title/name (`V<n>` → `v<n>`, else `current`). */
export declare function deriveSourceVersion(name: string, title: string): string;
/** NFKC + lowercase + keep only CJK/ASCII alnum (identifier normalization). */
export declare function normalizeAliasText(text: string): string;
//# sourceMappingURL=tokenizer.d.ts.map