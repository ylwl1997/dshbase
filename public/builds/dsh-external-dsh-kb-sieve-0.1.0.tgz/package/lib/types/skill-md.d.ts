/**
 * Generated SKILL.md — a zero-script DSH skill: pure instructions + pack
 * data. Retrieval happens through the plugin's kb_query / kb_read tools, so
 * the generated skill ships NO scripts, NO python, NO wrappers.
 *
 * Line numbers are INTERNAL locators: the model uses them to drive
 * kb_read (around/jump), but answers cite SECTIONS (heading names), never
 * raw line numbers — kb lines are meaningless to the reader and exact-line
 * chasing in huge documents is error-prone.
 *
 * @module @dsh-external/dsh-kb-sieve/skill-md
 */
export interface SkillMdOptions {
    skillName: string;
    title: string;
    docCount: number;
    /** Absolute path of the generated pack (skill bundle dir). */
    packDir: string;
}
/** Render the generated skill's SKILL.md (DSH flavor, concise). */
export declare function renderGeneratedSkillMd(opts: SkillMdOptions): string;
//# sourceMappingURL=skill-md.d.ts.map