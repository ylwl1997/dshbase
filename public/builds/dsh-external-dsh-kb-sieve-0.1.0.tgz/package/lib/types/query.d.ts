/**
 * Query engine — faithful port of the Python `kbtool_lib/query_engine.py`.
 *
 * Pipeline: std-number rewrite → FTS5 BM25 (title=10/body=1) → exact
 * identifier match → category boost → window-density rerank → line-level
 * matching → out-of-domain gate (identifier miss / OOV ratio) → confidence.
 * Output shape mirrors the original compact payload.
 *
 * @module @dsh-external/dsh-kb-sieve/query
 */
import { DatabaseSync } from 'node:sqlite';
/** Document category from source file / doc_id (port of _doc_category). */
export declare function docCategory(sourceFile: string, docId: string): string;
/**
 * Full-text window density (legacy packs without the line index).
 * Port of the Python formula: SET intersection of query ASCII tokens with
 * window ASCII tokens, plus CJK substring presence; short docs take
 * max(cjk, ascii); windows advance by `scanStep`.
 */
export declare function windowDensityScore(text: string, queryTokens: Set<string>, windowSize: number, scanStep: number): number;
/** Streaming density scan over line_text (reference path; O(lines)). Exported
 * for the equivalence regression test against the event-based index path. */
export declare function densityFromLineIndexStreaming(conn: DatabaseSync, docId: string, queryTokens: Set<string>, windowSize: number, scanStep: number): number;
/** Window density via line_fts hit events — cost O(hit lines), fully
 * decoupled from the document's total line count.
 *
 * A window [s, s+windowSize) covers token t iff t has a hit line l with
 * slot ∈ [l-windowSize, l-1]; with scanStep=5 and windowSize=20 each hit
 * line touches at most 4 window slots. We only inspect slots containing
 * ≥1 hit line (all other windows score 0).
 *
 * Tokens are restricted to pure [a-z]+ (the original window census extracts
 * words with `[a-z]+`, so digit/underscore tokens can never match a window —
 * counting them would flip rankings vs the legacy/streaming path).
 * MATCH is bounded per (token, doc) by the build-time rowid range, so memory
 * stays O(candidate hit lines), not O(corpus hit lines).
 */
/** Window density via line_fts hit events — cost O(hit lines), fully
 * decoupled from the document's total line count.
 *
 * A window [s, s+windowSize) covers token t iff t has a hit line l with
 * slot ∈ [l-windowSize, l-1]; with scanStep=5 and windowSize=20 each hit
 * line touches at most 4 window slots. We only inspect slots containing
 * ≥1 hit line (all other windows score 0).
 *
 * Tokens are restricted to pure [a-z]+ (the original window census extracts
 * words with `[a-z]+`), and line_fts stores each line's [a-z]+ word set, so
 * glued alnum tokens (GB50010-2010) expose their letter segments and
 * digit/underscore-only tokens never match — identical to the census.
 * The MATCH is scoped to candidate docs via a line_rowmap JOIN, so memory
 * stays O(candidate hit lines). An empty rowmap (stale/empty index) falls
 * back to the streaming scan per doc instead of silent zeros.
 */
export declare function densityScoresByIndex(conn: DatabaseSync, docIds: string[], queryTokens: Set<string>, windowSize: number, scanStep: number): Map<string, number>;
/** Read the original text from references/<doc_id>/doc.md (strip frontmatter). */
export declare function getDocBody(docId: string, packRoot: string): string;
/** Find lines containing any token: sorted by hit count desc, line number asc. */
export declare function findMatchingLines(bodyText: string, tokens: string[], maxMatches?: number): Array<{
    line: number;
    text: string;
}>;
/** Streamed line match over line_text. Never materializes the hit set:
 * keeps per-hit-count buckets of at most `maxMatches` rows (line-ascending,
 * so the first rows per bucket are the smallest line numbers — identical to
 * the old sort by (hitCount desc, line asc)) plus coverage flags.
 *
 * text_lower column detection is explicit (PRAGMA, O(1)): packs without it
 * (pre-text_lower builds that were not yet rebuilt) scan with
 * instr(lower(text), ?) and lowercase in JS — never a silent empty result
 * from a 'no such column' error. */
export declare function findMatchingLinesStream(conn: DatabaseSync, docId: string, tokens: string[], opts?: {
    maxMatches?: number;
    queryLower?: string;
}): {
    matches: Array<{
        line: number;
        text: string;
    }>;
    /** Lowercased tokens that occur on ≥1 line. */
    covered: Set<string>;
    /** Whether any line contains the whole query (lowercased). */
    phraseHit: boolean;
};
/** Line-level matching via line_text substring scan (SQL-instr, C speed):
 * identical semantics to the legacy full-text scan (lowercased substring
 * containment per token), memory O(hit lines). One query per candidate doc. */
export declare function findMatchingLinesByText(conn: DatabaseSync, docId: string, tokens: string[], maxMatches?: number): Array<{
    line: number;
    text: string;
}>;
/** Run a query against a knowledge pack. A corrupt/missing/empty kb.sqlite
 * (tampered or half-deleted pack) returns a no_hits result with an `error`
 * field instead of throwing a raw sqlite exception — the model can read the
 * failure and react (mirrors kb_read's graceful degradation). */
export interface QueryResult {
    tool: 'kbtool';
    cmd: 'query';
    query: string;
    status: 'high_confidence' | 'needs_verification' | 'no_hits';
    fts_match: string;
    results: Array<{
        file: string;
        doc_id: string;
        title: string;
        score: number;
        matches: Array<{
            line: number;
            text: string;
        }>;
    }>;
    next_action: string;
    oos_reason?: string;
    /** Set when the pack database is unreadable (corrupt/missing). */
    error?: string;
    /** Set when the pack predates the physical-doc.md line base (stale lines). */
    warning?: string;
}
export declare function runQuery(packRoot: string, rawQuery: string, opts?: {
    limit?: number;
    docIds?: string[];
}): QueryResult;
//# sourceMappingURL=query.d.ts.map