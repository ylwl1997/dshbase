/**
 * dsh-kb-sieve — 知识库筛子插件。
 *
 * 把文档（md/txt/docx/pdf）构建成可审计知识包（references/ + kb.sqlite FTS5），
 * 并提供确定性检索（kb_query）与原文精读（kb_read）两个运行时工具。纯计算，
 * 零子代理、零 workflow、零外部服务——inject 只需要工具注册服务。
 *
 * 生成的 skill 是纯数据（SKILL.md 指令 + references/ + kb.sqlite），零脚本零
 * Python；输出到监听中的 skill 根目录（当前项目根目录的 .dsh/skills）
 * 时，DSH 动态发现并加载，实现"安装即用"的知识库。
 *
 * Native TypeScript source: the package entry points at this file and no build
 * step exists. In a dsh profile the package lives under node_modules, so it
 * loads through the dsh source launcher's whole-process tsx hook (Node's
 * native type stripping refuses files under node_modules); a checkout run
 * outside node_modules can also load via Node >=22.18 native stripping.
 * Syntax must stay erasable-only (no enums/namespaces/parameter properties).
 *
 * @module @dsh-external/dsh-kb-sieve
 */
import type { Context } from 'cordis';
export declare const name = "dsh-kb-sieve";
/** Activate once the tool registry is available. */
export declare const inject: string[];
/** Loader-validated plugin config (all keys optional). */
export interface Config {
    /** Default output parent for kb_build (the pack lands in `<defaultOutDir>/<name>`). */
    defaultOutDir?: string;
}
/** Resolve the default skill output root: always the CURRENT PROJECT ROOT —
 * <nearest .git>/.dsh/skills, else <cwd>/.dsh/skills. Never falls back to
 * the user's home (~/.dsh/skills): users expect the knowledge base to land
 * in the working directory's project, and DSH discovers project-level
 * .dsh/skills wherever the session runs. Exported for tests. */
export declare function resolveDefaultOutDir(): string;
/** Apply the plugin: register kb_build / kb_query / kb_read. */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map