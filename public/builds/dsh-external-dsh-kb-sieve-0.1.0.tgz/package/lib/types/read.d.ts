/**
 * Read engine — kb_read implementation.
 *
 * Indexed packs (line_text exists): every mode is answered with precise SQL
 * range/point reads — no full-document read, no 866K-line array. Legacy
 * packs (built by the Python original, no line_text) fall back to reading
 * references/<doc_id>/doc.md.
 *
 * Line numbers are PHYSICAL doc.md lines (the line-number base for the whole
 * query/read pipeline — what the model sees is what it can verify by reading
 * references/<doc_id>/doc.md).
 *
 * @module @dsh-external/dsh-kb-sieve/read
 */
/** Resolve references/<doc_id>/doc.md, rejecting path traversal AND symlink escape. */
export declare function resolveDocPath(packRoot: string, docId: string): string | null;
/** One per-doc read result (mode-dependent extra fields). */
export type ReadDoc = {
    doc_id: string;
} & Record<string, unknown>;
export interface ReadResult {
    tool: 'kbtool';
    cmd: 'read';
    tokens: string[];
    docs: ReadDoc[];
    /** Set when the pack was built with an older index layout (stale line base). */
    warning?: string;
}
export interface ReadOptions {
    docId: string | string[];
    tokens?: string;
    sections?: boolean;
    around?: number;
    expand?: number;
    find?: string;
    /** 1-based start line; rows strictly AFTER it are searched (default 0 = from the top). */
    after?: number;
    jump?: string;
    start?: number;
    count?: number;
}
/** Run a read against a knowledge pack. */
export declare function runRead(packRoot: string, opts: ReadOptions): ReadResult;
//# sourceMappingURL=read.d.ts.map