/**
 * Build orchestration — port of the Python `build.py` core path (whole-doc,
 * non-incremental). Produces an auditable knowledge pack:
 *
 *   <pack>/SKILL.md  <pack>/manifest.json  <pack>/kb.sqlite
 *   <pack>/references/<doc_id>/{doc.md, metadata.md, structure_report.json}
 *
 * @module @dsh-external/dsh-kb-sieve/build
 */

import { copyFileSync, existsSync, readFileSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, rename, rm, writeFile } from 'node:fs/promises'
import { basename, dirname, join, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { extractToMarkdown, BuildError } from './extract.ts'
import { openKbForWrite, writeDoc, deleteDoc, finalizeKb } from './db.ts'
import { ftsTokens, deriveSourceVersion } from './tokenizer.ts'
import { renderGeneratedSkillMd } from './skill-md.ts'
import { INDEX_VERSION } from './constants.ts'

/** Slugify a stem into a readable doc_id base: ASCII alnum + CJK ideographs
 * are kept (CJK file names yield readable ids like "混凝土结构设计规范"),
 * everything else collapses to '-'. Version markers and letter/digit
 * boundaries are preserved like the original. */
function slugifyAscii(stem: string): string {
  let s = stem.normalize('NFKC').toLowerCase()
  // Preserve version markers: "docV3" → "doc-v3" (not "docv-3").
  s = s.replace(/(?<![a-z0-9\u4e00-\u9fff])v(?=\d+\b)/g, 'versionkeep_')
  // Insert '-' at letter/digit boundaries so "GB50010" → "gb-50010".
  s = s.replace(/([a-z])(\d)/g, '$1-$2')
  s = s.replace(/(\d)([a-z])/g, '$1-$2')
  s = s.replace('versionkeep_', 'v')
  // Normalize full-width/CJK brackets and punctuation to ASCII.
  const bracketMap: Array<[string, string]> = [
    ['〔', '['], ['〕', ']'],
    ['（', '('], ['）', ')'],
    ['《', ''], ['》', ''],
    ['　', '-'],
  ]
  for (const [old, replacement] of bracketMap) {
    s = s.replaceAll(old, replacement)
  }
  // Keep ASCII alnum AND CJK ideographs; drop everything else.
  s = s.replace(/[^a-z0-9\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]+/g, '-')
  s = s.replace(/-{2,}/g, '-').replace(/^-+|-+$/g, '')
  return s || 'doc'
}

/** Common ancestor of absolute paths (doc_id disambiguation hash base). */
function commonPrefix(paths: string[]): string {
  if (paths.length === 0) return ''
  let prefix = dirname(paths[0]!)
  for (const p of paths.slice(1)) {
    while (!p.startsWith(prefix)) {
      const parent = dirname(prefix)
      if (parent === prefix) return prefix
      prefix = parent
    }
  }
  return prefix
}

/**
 * Order-independent doc_id assignment: every input maps to a slugified base
 * (CJK kept); bases unique across the input set stay as-is, collisions get a
 * deterministic suffix from the path RELATIVE to the inputs' common prefix.
 * Reordering inputs or inserting a new file never reshuffles existing ids.
 */
function assignDocIds(inputs: string[]): Map<string, string> {
  const baseOf = new Map<string, string>()
  for (const abs of inputs) {
    const stem = basename(abs, extname(abs))
    let base = slugifyAscii(stem)
    if (base.length > 48) base = base.slice(0, 48).replace(/-+$/, '') || 'doc'
    baseOf.set(abs, base)
  }
  const counts = new Map<string, number>()
  for (const base of baseOf.values()) counts.set(base, (counts.get(base) ?? 0) + 1)
  const root = commonPrefix(inputs)
  const out = new Map<string, string>()
  for (const abs of inputs) {
    const base = baseOf.get(abs)!
    if (counts.get(base) === 1) {
      out.set(abs, base)
    } else {
      const rel = abs.startsWith(root) ? abs.slice(root.length) : abs
      const h = createHash('sha256').update(rel, 'utf8').digest('hex').slice(0, 8)
      out.set(abs, `${base}-${h}`)
    }
  }
  return out
}

function extname(path: string): string {
  const m = /(\.[^.\\/]+)$/.exec(path)
  return m?.[1] ?? ''
}

/** Derive the document title from the first heading (or filename stem). */
function deriveDocTitle(path: string, md: string): string {
  for (const raw of md.split('\n')) {
    const line = raw.replace(/^\uFEFF/, '').trim()
    if (!line) continue
    if (line.startsWith('#')) {
      const title = line.replace(/^#{1,6}\s+/, '').trim()
      return title || basename(path, extname(path))
    }
    break
  }
  return basename(path, extname(path))
}

/** Per-line markdown-to-plain + FTS tokenization, space-joined. Equivalent to
 * tokenizing the whole plain text (CJK runs cannot span lines) at O(line)
 * memory instead of holding the whole document's token array. */
function tokenizeBody(canonical: string): string {
  const parts: string[] = []
  for (const raw of canonical.split('\n')) {
    const line = raw.trim()
    let plain = line.replace(/^#{1,6}\s+/, '')
    plain = plain.replace(/`([^`]*)`/g, '$1')
    plain = plain.replace(/\[(.*?)\]\((.*?)\)/g, '[$1]')
    plain = plain.replaceAll('**', '').replaceAll('__', '').replaceAll('*', '')
    parts.push(ftsTokens(plain).join(' '))
  }
  return parts.join(' ')
}

/** NFKC + LF normalization + trailing newline (canonical text). */
export function normalizeCanonicalText(text: string): string {
  let value = text.normalize('NFKC').replace(/\r\n/g, '\n').replace(/\r/g, '\n')
  if (!value.endsWith('\n')) value += '\n'
  return value
}

/** Extract heading entries (title, level) from markdown text. */
function extractHeadings(text: string): Array<{ title: string; level: number }> {
  const entries: Array<{ title: string; level: number }> = []
  for (const line of text.split('\n')) {
    const m = /^(#{1,6})\s+(.+)/.exec(line.trimStart())
    if (m) {
      entries.push({ title: m[2]?.trim() ?? '', level: m[1]?.length ?? 0 })
    }
  }
  return entries
}

/** kb-node style YAML frontmatter (JSON-quoted values, mirroring render/node.py). */
function frontmatterKbNode(opts: {
  docId: string
  docTitle: string
  sourceFile: string
  nodeId: string
  kind: string
  label: string
  title: string
  parentId: string
  refPath: string
}): string {
  const j = (v: string): string => JSON.stringify(v)
  return [
    '---',
    `doc_id: ${j(opts.docId)}`,
    `doc_title: ${j(opts.docTitle)}`,
    `source_file: ${j(opts.sourceFile)}`,
    `node_id: ${j(opts.nodeId)}`,
    `kind: ${j(opts.kind)}`,
    `label: ${j(opts.label)}`,
    `title: ${j(opts.title)}`,
    `parent_id: ${j(opts.parentId)}`,
    `ref_path: ${j(opts.refPath)}`,
    '---',
    '',
  ].join('\n') + '\n'
}

export interface BuiltDoc {
  docId: string
  title: string
  sourceFile: string
  sourcePath: string
  docHash: string
  sourceVersion: string
  canonical: string // canonical markdown text
  /** doc.md body (frontmatter stripped) — the exact text kb_read reads, so
   *  the line index and read-engine line numbers stay aligned. */
  bodyText: string
}

export interface BuildResult {
  skillRoot: string
  skillName: string
  title: string
  docCount: number
  docIds: string[]
  errors: string[]
  generatedAt: string
}

const SKILL_NAME_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/

/** One document's source-level build state (incremental fingerprinting). */
interface DocStateEntry {
  source_path: string
  source_fingerprint: string
  extracted_text_fingerprint: string
  doc_hash: string
  doc_title: string
}

interface BuildState {
  artifact_version: string
  /** Index layout version (see constants.ts): builds whose state predates it
   * are force-rebuilt once so rows are rewritten under the current line base
   * — a stale pack must never keep old line numbers while new docs use the
   * new base. */
  index_version: number
  created_at: string
  documents: Record<string, Record<string, DocStateEntry>>
}

const ARTIFACT_VERSION = 'kb-sieve.ts.v2'
const BUILD_STATE_FILENAME = 'build_state.json'

/** Load the previous build state (null when absent/unreadable/mismatched). */
function loadBuildState(target: string): BuildState | null {
  try {
    const data = JSON.parse(readFileSync(join(target, BUILD_STATE_FILENAME), 'utf8')) as Partial<BuildState>
    if (data.artifact_version !== ARTIFACT_VERSION) return null
    if (typeof data.documents !== 'object' || data.documents === null) return null
    return data as BuildState
  } catch {
    return null
  }
}

function sha256Hex(text: string | Uint8Array): string {
  if (typeof text === 'string') {
    return createHash('sha256').update(text, 'utf8').digest('hex')
  }
  return createHash('sha256').update(text).digest('hex')
}

export interface BuildOptions {
  skillName: string
  title: string
  inputs: string[]
  outDir: string
  /** true: incremental when a compatible build_state exists (default); false: full rebuild. */
  force: boolean
  /** Extraction concurrency (default 4, capped 8) — bounds peak memory. */
  workers?: number
}

export interface BuildResult {
  skillRoot: string
  skillName: string
  title: string
  docCount: number
  docIds: string[]
  errors: string[]
  generatedAt: string
  /** Incremental statistics (full builds: everything counts as 'added'). */
  stats: { unchanged: number; changed: number; added: number; removed: number; failed: number }
}

/** sha256 of the file's raw bytes (L1 fingerprint — no extraction needed). */
async function sourceFingerprint(abs: string): Promise<string> {
  const data = await readFile(abs)
  return sha256Hex(data)
}

/**
 * Build (or incrementally update) a knowledge pack.
 *
 * Pipeline: doc_ids are assigned in input order (deterministic across runs);
 * extraction runs with bounded concurrency; each document is written
 * (references + SQLite rows) as soon as it finishes and its text is released
 * immediately, so peak memory ≈ workers × one document's text — no
 * whole-corpus accumulation.
 *
 * Incremental (when a compatible build_state.json exists and force=false):
 * - unchanged:  source bytes fingerprint matches → skipped entirely
 * - changed:    re-extracted and rewritten (deleteDoc + writeDoc)
 * - new:        inserted
 * - removed:    inputs no longer contain a previously indexed path → deleteDoc
 * The kb.sqlite copy is updated in a temp file and atomically renamed back.
 */
export async function buildSkill(opts: BuildOptions): Promise<BuildResult> {
  if (!SKILL_NAME_RE.test(opts.skillName)) {
    throw new BuildError(
      `Invalid skill name "${opts.skillName}": lowercase letters/digits/hyphens only (e.g. my-books).`,
    )
  }
  if (opts.inputs.length === 0) throw new BuildError('No inputs: pass at least one .md/.txt/.docx/.pdf file')

  const outDir = resolve(opts.outDir)
  const target = join(outDir, opts.skillName)
  const workers = Math.max(1, Math.min(8, opts.workers ?? 4))
  const targetExists = existsSync(target)
  if (targetExists && !opts.force && !existsSync(join(target, BUILD_STATE_FILENAME))) {
    throw new BuildError(`Output already exists without a build state: ${target} (pass force: true to overwrite)`)
  }
  await mkdir(outDir, { recursive: true })

  // mkdtemp: unpredictable name defeats symlink pre-planting in outDir.
  const tmp = await mkdtemp(join(outDir, `.${opts.skillName}.tmp-`))
  const stats = { unchanged: 0, changed: 0, added: 0, removed: 0, failed: 0 }
  const errors: string[] = []
  const generatedAt = new Date().toISOString()

  try {
    // ── doc_id assignment (order-independent, CJK-readable) ──
    const inputs = opts.inputs.map((p) => resolve(p))
    const docIdByPath = assignDocIds(inputs)
    const plan = inputs.map((abs) => ({ abs, docId: docIdByPath.get(abs)! }))

    // ── incremental classification ──
    const previous = !opts.force ? loadBuildState(target) : null
    // Stale index layout (pre-text_lower / pre-physical-line-base builds):
    // rebuild everything once under the current line base. loadBuildState
    // already gates on artifact_version; index_version is the finer-grained
    // gate for index layout changes within the same artifact generation.
    const indexStale = previous !== null && (previous.index_version ?? 0) < INDEX_VERSION
    const useIncremental = previous !== null && targetExists && !indexStale
    const stateByPath = new Map<string, [string, string, DocStateEntry]>() // abs -> docId, sv, entry
    if (useIncremental && previous) {
      for (const [docId, versions] of Object.entries(previous.documents)) {
        for (const [sv, entry] of Object.entries(versions)) {
          stateByPath.set(resolve(entry.source_path), [docId, sv, entry])
        }
      }
    }
    const inputPaths = new Set(plan.map((p) => p.abs))
    const removedDocs: Array<[string, string]> = [] // docId, source_version
    if (useIncremental && previous) {
      for (const [docId, versions] of Object.entries(previous.documents)) {
        for (const [sv, entry] of Object.entries(versions)) {
          const abs = resolve(entry.source_path)
          if (!inputPaths.has(abs)) {
            removedDocs.push([docId, sv])
          } else if (docIdByPath.get(abs) !== docId) {
            // doc_id reassigned (e.g. slug rule change or new collision):
            // the old id is retired and the path is rebuilt under the new id.
            removedDocs.push([docId, sv])
          }
        }
      }
      stats.removed = removedDocs.length
    }

    // ── concurrent extraction pipeline: each finished doc is written and released ──
    const finalDocs: Array<{ docId: string; title: string; sourceFile: string; sourcePath: string; docHash: string; sourceVersion: string }> = []
    const dbTarget = join(tmp, 'kb.sqlite')
    if (useIncremental && targetExists) {
      copyFileSync(join(target, 'kb.sqlite'), dbTarget)
    }
    const conn = openKbForWrite(dbTarget)
    let finalized = false
    try {
      // Incremental deletions first (independent of extraction results).
      if (removedDocs.length > 0) {
        conn.exec('BEGIN')
        for (const [docId] of removedDocs) {
          deleteDoc(conn, docId)
        }
        conn.exec('COMMIT')
      }

      let cursor = 0
      const run = async (): Promise<void> => {
        for (;;) {
          const i = cursor++
          if (i >= plan.length) return
          const { abs, docId } = plan[i]!
          try {
            // L1: source bytes unchanged → skip extraction entirely.
            const entryByPath = useIncremental ? stateByPath.get(abs) : undefined
            if (entryByPath) {
              const [, sv, entry] = entryByPath
              if (entry.source_path === abs && await sourceFingerprint(abs) === entry.source_fingerprint) {
                finalDocs.push({
                  docId, title: entry.doc_title, sourceFile: basename(abs), sourcePath: abs,
                  docHash: entry.doc_hash, sourceVersion: sv,
                })
                stats.unchanged += 1
                continue
              }
            }

            // Extract (L2 fingerprint decides changed vs new).
            const md = await extractToMarkdown(abs)
            const canonical = normalizeCanonicalText(md)
            const title = deriveDocTitle(abs, canonical)
            const docHash = sha256Hex(md)
            const sourceVersion = deriveSourceVersion(basename(abs, extname(abs)), title)
            const wasIndexed = entryByPath !== undefined
            const doc: BuiltDoc = {
              docId, title, sourceFile: basename(abs), sourcePath: abs,
              docHash, sourceVersion, canonical, bodyText: '',
            }
            // References: writeReferences creates tmp/references/<docId>.
            // Incremental replaces each doc dir atomically in the live pack;
            // full builds move the whole tmp tree (rm(target) below would
            // wipe per-doc renames into target).
            // bodyText = the FULL doc.md text (frontmatter included): line
            // numbers become the physical doc.md line numbers the model can
            // verify by reading references/<doc_id>/doc.md.
            doc.bodyText = await writeReferences(tmp, doc)
            if (useIncremental) {
              const refTargetDir = join(target, 'references', docId)
              await rm(refTargetDir, { recursive: true, force: true })
              await mkdir(dirname(refTargetDir), { recursive: true })
              await rename(join(tmp, 'references', docId), refTargetDir)
            }

            // DB rows (writeDoc self-manages batched transactions).
            if (wasIndexed) {
              conn.exec('BEGIN')
              deleteDoc(conn, docId)
              conn.exec('COMMIT')
            }
            writeDoc(conn, {
              docId, docTitle: title, sourceFile: basename(abs), sourcePath: abs,
              docHash, sourceVersion, isActive: true,
              // FTS body strips markdown per line and tokenizes per line
              // (CJK runs never span lines, so line-wise tokenization equals
              // whole-document tokenization) — memory stays O(line).
              body: tokenizeBody(canonical),
              bodyText: doc.bodyText,
              canonicalLineCount: canonical.endsWith('\n') ? canonical.split('\n').length - 1 : canonical.split('\n').length,
            })

            finalDocs.push({ docId, title, sourceFile: basename(abs), sourcePath: abs, docHash, sourceVersion })
            if (wasIndexed) stats.changed += 1
            else stats.added += 1
            // Release the document's text for GC before the next iteration.
            doc.canonical = ''
            doc.bodyText = ''
          } catch (error) {
            errors.push(`${abs}: ${(error as Error).message}`)
            stats.failed += 1
          }
        }
      }
      await Promise.all(Array.from({ length: Math.min(workers, plan.length) }, () => run()))
      // Deterministic output: docIds are sorted (completion order is concurrent).
      finalDocs.sort((x, y) => (x.docId < y.docId ? -1 : x.docId > y.docId ? 1 : 0))

      // Manifest + SKILL.md (full rewrite — cheap).
      await writeFile(
        join(tmp, 'manifest.json'),
        JSON.stringify({
          skill_name: opts.skillName,
          title: opts.title,
          generated_at: generatedAt,
          docs: finalDocs.map((d) => ({
            doc_id: d.docId,
            title: d.title,
            source_file: d.sourceFile,
            source_path: d.sourcePath,
            doc_hash: d.docHash,
            source_version: d.sourceVersion,
            active_version: true,
          })),
        }, null, 2) + '\n',
        'utf8',
      )
      await writeFile(
        join(tmp, 'SKILL.md'),
        renderGeneratedSkillMd({
          skillName: opts.skillName,
          title: opts.title,
          docCount: finalDocs.length,
          packDir: target,
        }),
        'utf8',
      )
      // Build state.
      const state: BuildState = {
        artifact_version: ARTIFACT_VERSION,
        index_version: INDEX_VERSION,
        created_at: generatedAt,
        documents: {},
      }
      for (const d of finalDocs) {
        state.documents[d.docId] ??= {}
        state.documents[d.docId]![d.sourceVersion] = {
          source_path: d.sourcePath,
          source_fingerprint: '',
          extracted_text_fingerprint: '',
          doc_hash: d.docHash,
          doc_title: d.title,
        }
      }
      // Unchanged docs carry their previous fingerprints; changed/new docs
      // recompute the source fingerprint (the text is already released).
      if (useIncremental && previous) {
        for (const d of finalDocs) {
          const prev = previous.documents[d.docId]?.[d.sourceVersion]
          if (prev) {
            state.documents[d.docId]![d.sourceVersion] = { ...prev, doc_hash: d.docHash, doc_title: d.title }
          }
        }
      }
      for (const versions of Object.values(state.documents)) {
        for (const entry of Object.values(versions)) {
          if (!entry.source_fingerprint) {
            try {
              entry.source_fingerprint = await sourceFingerprint(entry.source_path)
            } catch {
              entry.source_fingerprint = ''
            }
          }
        }
      }
      await writeFile(join(tmp, BUILD_STATE_FILENAME), JSON.stringify(state, null, 2) + '\n', 'utf8')

      // Finalize DB: commit + indexes + optimize + checkpoint WAL, then close.
      finalizeKb(conn)
      try {
        conn.exec('PRAGMA wal_checkpoint(TRUNCATE)')
      } catch {
        // read-only fs or non-WAL mode: the copy is still consistent on close
      }
      conn.close()
      finalized = true
    } finally {
      if (!finalized) conn.close()
    }

    // ── atomic swap of the mutable artifacts ──
    if (useIncremental) {
      // kb.sqlite replaced in place (updated copy), references already replaced
      // per doc, manifest/SKILL.md/build_state renamed over. The tmp tree is
      // consumed by renames except for empty references/ shells — remove it.
      await rename(dbTarget, join(target, 'kb.sqlite'))
      await rename(join(tmp, 'manifest.json'), join(target, 'manifest.json'))
      await rename(join(tmp, 'SKILL.md'), join(target, 'SKILL.md'))
      await rename(join(tmp, BUILD_STATE_FILENAME), join(target, BUILD_STATE_FILENAME))
      await rm(tmp, { recursive: true, force: true })
    } else {
      await rm(target, { recursive: true, force: true })
      // Move the assembled tmp tree (references/ + kb.sqlite + manifests) as a
      // whole into the target.
      await rename(tmp, target)
    }

    if (finalDocs.length === 0) {
      throw new BuildError(`No documents could be extracted (${errors.length} failed): ${errors.join('; ')}`)
    }

    // References hygiene: remove doc dirs that are no longer in the pack.
    {
      const finalIds = new Set(finalDocs.map((d) => d.docId))
      const refsRoot = join(target, 'references')
      try {
        const entries = await readdir(refsRoot, { withFileTypes: true })
        for (const e of entries) {
          if (e.isDirectory() && !finalIds.has(e.name)) {
            await rm(join(refsRoot, e.name), { recursive: true, force: true })
          }
        }
      } catch {
        // references dir may not exist yet on first build — fine
      }
    }

    return {
      skillRoot: target,
      skillName: opts.skillName,
      title: opts.title,
      docCount: finalDocs.length,
      docIds: finalDocs.map((d) => d.docId),
      errors,
      generatedAt,
      stats,
    }
  } catch (error) {
    await rm(tmp, { recursive: true, force: true }).catch(() => {})
    throw error
  }
}

/** Write references/<doc_id>/{doc.md, metadata.md, structure_report.json};
 * returns the FULL doc.md text (frontmatter + wrapper + original) — the
 * line-number base for the whole query/read pipeline. */
async function writeReferences(packRoot: string, d: BuiltDoc): Promise<string> {
  const docDir = join(packRoot, 'references', d.docId)
  await mkdir(docDir, { recursive: true })

  const rel = `references/${d.docId}/doc.md`
  const headings = extractHeadings(d.canonical)
  const lineCount = d.canonical.endsWith('\n') ? d.canonical.split('\n').length - 1 : d.canonical.split('\n').length
  const charCount = d.canonical.length

  // Element structure mirrors the original renderer (elements carry their
  // trailing newline, then join('\n') — byte-identical doc.md layouts).
  const bodyLines: string[] = [
    `# ${d.title}\n`,
    '',
  ]
  if (headings.length > 0) {
    bodyLines.push('## 目录\n')
    for (const h of headings) {
      bodyLines.push(`${'  '.repeat(h.level - 1)}- ${h.title}`)
    }
    bodyLines.push('')
  }
  bodyLines.push('## 统计\n')
  bodyLines.push(`- 行数: ${lineCount}`)
  bodyLines.push(`- 字符数: ${charCount}`)
  bodyLines.push('')
  bodyLines.push('---\n')
  bodyLines.push('')
  bodyLines.push(d.canonical.replace(/\s+$/, ''))
  bodyLines.push('')

  const docMd =
    frontmatterKbNode({
      docId: d.docId,
      docTitle: d.title,
      sourceFile: d.sourceFile,
      nodeId: `${d.docId}:doc`,
      kind: 'doc',
      label: d.docId,
      title: d.title,
      parentId: '',
      refPath: rel,
    }) + bodyLines.join('\n') + '\n'

  const metadata = [
    `# ${d.title}`,
    '',
    `- 源文件：\`${d.sourceFile}\``,
    `- 源路径：\`${d.sourcePath}\``,
    `- 版本：\`${d.sourceVersion}\``,
    `- 文档哈希：\`${d.docHash}\``,
    '- 解析器：`whole_doc`',
    '',
  ].join('\n')

  const structure = JSON.stringify({
    doc_id: d.docId,
    doc_title: d.title,
    source_file: d.sourceFile,
    source_path: d.sourcePath,
    source_version: d.sourceVersion,
    selected_parser: 'whole_doc',
    runner_ups: [],
    selected_report: {
      mode: 'whole_document',
      stats: { line_count: lineCount, char_count: charCount, heading_count: headings.length },
    },
  }, null, 2) + '\n'

  await writeFile(join(docDir, 'doc.md'), docMd, 'utf8')
  await writeFile(join(docDir, 'metadata.md'), metadata, 'utf8')
  await writeFile(join(docDir, 'structure_report.json'), structure, 'utf8')
  return docMd
}
