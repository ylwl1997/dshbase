/**
 * Read engine — kb_read implementation.
 *
 * Indexed packs (line_text exists): every mode is answered with precise SQL
 * range/point reads — no full-document read, no 866K-line array. Legacy
 * packs (built by the Python original, no line_text) fall back to reading
 * references/<doc_id>/doc.md.
 *
 * Line numbers are PHYSICAL doc.md lines (the line-number base for the whole
 * query/read pipeline — what the model sees is what it can verify by reading
 * references/<doc_id>/doc.md).
 *
 * @module @dsh-external/dsh-kb-sieve/read
 */

import { readFileSync, realpathSync } from 'node:fs'
import { join, relative } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { ftsTokens } from './tokenizer.ts'
import { INDEX_VERSION } from './constants.ts'
import { isHeadingLine } from './heading.ts'

/** Hard cap on lines returned per doc (guards against runaway ranges). */
const MAX_READ_LINES = 2000

/** A warning when the pack predates the physical-doc.md line base (its line
 * numbers are misaligned with doc.md until rebuilt). Absent build state
 * (Python-original packs) reads fine — those are served by the legacy path. */
function packIndexWarning(packRoot: string): string | undefined {
  try {
    const state = JSON.parse(readFileSync(join(packRoot, 'build_state.json'), 'utf8')) as { index_version?: number }
    if (typeof state.index_version !== 'number' || state.index_version < INDEX_VERSION) {
      return 'pack was built with an older index layout: line numbers are not doc.md physical lines; run kb_build to rebuild'
    }
  } catch {
    // no build state — legacy pack, fine
  }
  return undefined
}

/** Resolve references/<doc_id>/doc.md, rejecting path traversal AND symlink escape. */
export function resolveDocPath(packRoot: string, docId: string): string | null {
  if (!docId || docId.includes('/') || docId.includes('\\') || docId.includes('..')) return null
  const p = join(packRoot, 'references', docId, 'doc.md')
  try {
    // Defense in depth: the REAL path (symlinks followed) must stay under
    // references/. The verified real path is returned and read, closing the
    // check-then-read window (TOCTOU).
    const real = realpathSync(p)
    const refsRoot = realpathSync(join(packRoot, 'references'))
    if (relative(refsRoot, real).startsWith('..')) return null
    return real
  } catch {
    return null
  }
}

/** Extract sections from a title-row list (indexed path). */
function sectionsFromTitleRows(
  rows: Array<{ line_number: number; text: string }>,
  totalLines: number,
): Array<{ line: number; end_line: number; heading: string; line_count: number }> {
  const titles: Array<{ line: number; text: string }> = []
  for (const r of rows) {
    if (isHeadingLine(r.text)) titles.push({ line: r.line_number, text: r.text.trim() })
  }
  const out: Array<{ line: number; end_line: number; heading: string; line_count: number }> = []
  for (let i = 0; i < titles.length; i++) {
    const t = titles[i]!
    const endLine = i + 1 < titles.length ? titles[i + 1]!.line - 1 : totalLines
    out.push({ line: t.line, end_line: endLine, heading: t.text.slice(0, 120), line_count: endLine - t.line + 1 })
  }
  return out
}

/** Section list over a file's lines — same semantics as the indexed path
 * (title rows only, physical 1-based line numbers). */
function sectionsFromLines(lines: string[]): Array<{ line: number; end_line: number; heading: string; line_count: number }> {
  const rows: Array<{ line_number: number; text: string }> = []
  for (let i = 0; i < lines.length; i++) {
    if (isHeadingLine(lines[i] ?? '')) rows.push({ line_number: i + 1, text: lines[i]! })
  }
  return sectionsFromTitleRows(rows, lines.length)
}

/** Section containing a line, from a section list (or null → pre-heading
 * region: the caller reads [1, firstTitle-1]). */
function sectionContaining(
  sections: Array<{ line: number; end_line: number }>,
  targetLine: number,
): { line: number; end_line: number } | null {
  for (const s of sections) {
    if (targetLine >= s.line && targetLine <= s.end_line) return s
  }
  return null
}

function markHits(linesData: Array<{ line: number; text: string; hits: number }>, tokens: string[]): void {
  const tokenLowers = tokens.filter(Boolean).map((t) => t.toLowerCase())
  if (tokenLowers.length === 0) return
  for (const entry of linesData) {
    const lineLower = (entry.text ?? '').toLowerCase()
    entry.hits = tokenLowers.reduce((acc, t) => acc + (lineLower.includes(t) ? 1 : 0), 0)
  }
}

function readRange(lines: string[], start: number, count: number): Array<{ line: number; text: string; hits: number }> {
  const result: Array<{ line: number; text: string; hits: number }> = []
  for (let i = Math.max(0, start - 1); i < Math.min(lines.length, start - 1 + count); i++) {
    result.push({ line: i + 1, text: (lines[i] ?? '').replace(/\s+$/, ''), hits: 0 })
  }
  return result
}

/** One per-doc read result (mode-dependent extra fields). */
export type ReadDoc = { doc_id: string } & Record<string, unknown>

export interface ReadResult {
  tool: 'kbtool'
  cmd: 'read'
  tokens: string[]
  docs: ReadDoc[]
  /** Set when the pack was built with an older index layout (stale line base). */
  warning?: string
}

export interface ReadOptions {
  docId: string | string[]
  tokens?: string
  sections?: boolean
  around?: number
  expand?: number
  find?: string
  /** 1-based start line; rows strictly AFTER it are searched (default 0 = from the top). */
  after?: number
  jump?: string
  start?: number
  count?: number
}

interface IndexRead {
  conn: DatabaseSync
  totalLinesOf: (docId: string) => number
  titleRows: (docId: string) => Array<{ line_number: number; text: string }>
  rangeRead: (docId: string, start: number, count: number) => Array<{ line: number; text: string }>
  findRow: (docId: string, afterLine: number, findLower: string) => { line_number: number } | null
}

/** Open the pack's kb.sqlite for reading (null → legacy file fallback). */
function openIndex(packRoot: string): IndexRead | null {
  try {
    const conn = new DatabaseSync(join(packRoot, 'kb.sqlite'), { readOnly: true })
    conn.exec('PRAGMA cache_size = -65536')
    conn.exec('PRAGMA mmap_size = 268435456')
    conn.exec('PRAGMA temp_store = MEMORY')
    const hasLineText = conn.prepare(
      "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'line_text'",
    ).get() !== undefined
    if (!hasLineText) {
      conn.close()
      return null
    }
    const maxLine = conn.prepare('SELECT MAX(line_number) AS m FROM line_text WHERE doc_id = ?')
    // Heading rows are materialized at build time (line_text.is_heading):
    // index point-read instead of scanning every line with a SQL regex
    // approximation. Missing column (pre-migration pack, read-only access)
    // → prepare error → openIndex null → legacy file path (correct lines).
    const titleStmt = conn.prepare(
      'SELECT line_number, text FROM line_text WHERE doc_id = ? AND is_heading = 1 ORDER BY line_number',
    )
    const rangeStmt = conn.prepare(
      'SELECT line_number, text FROM line_text WHERE doc_id = ? AND line_number BETWEEN ? AND ? ORDER BY line_number',
    )
    // find matches with JS-lowercase semantics. With the text_lower column:
    // instr(COALESCE(text_lower, lower(text)), ?) — NULL rows degrade to
    // SQLite lower() (ASCII-exact) so a tampered pack is not silently empty.
    // WITHOUT the column (pre-text_lower pack): SQLite lower() would miss
    // non-ASCII queries (it folds ASCII only, unlike JS toLowerCase), so the
    // scan runs in JS over line_number >= after — same semantics as the
    // legacy file path.
    const cols = conn.prepare('PRAGMA table_info(line_text)').all() as Array<{ name: string }>
    const hasLowerCol = cols.some((c) => c.name === 'text_lower')
    let findRow: (docId: string, afterLine: number, findLower: string) => { line_number: number } | null
    if (hasLowerCol) {
      const findStmt = conn.prepare(
        `SELECT line_number FROM line_text WHERE doc_id = ? AND line_number >= ? AND instr(COALESCE(text_lower, lower(text)), ?) > 0 ORDER BY line_number LIMIT 1`,
      )
      findRow = (docId, afterLine, findLower) =>
        (findStmt.get(docId, afterLine + 1, findLower) as { line_number: number } | undefined) ?? null
    } else {
      const scanStmt = conn.prepare(
        'SELECT line_number, text FROM line_text WHERE doc_id = ? AND line_number >= ? ORDER BY line_number',
      )
      findRow = (docId, afterLine, findLower) => {
        for (const row of scanStmt.iterate(docId, afterLine + 1) as Iterable<{ line_number: number; text: string | null }>) {
          if (row.text != null && row.text.toLowerCase().includes(findLower)) return { line_number: row.line_number }
        }
        return null
      }
    }
    return {
      conn,
      totalLinesOf: (docId) => (maxLine.get(docId) as { m: number | null }).m ?? 0,
      titleRows: (docId) => titleStmt.all(docId) as Array<{ line_number: number; text: string }>,
      rangeRead: (docId, start, count) => {
        if (count <= 0) return []
        const rows = rangeStmt.all(docId, start, start + count - 1) as Array<{ line_number: number; text: string | null }>
        // NULL text rows (tampered packs) degrade to '' instead of throwing.
        return rows.map((r) => ({ line: r.line_number, text: (r.text ?? '').replace(/\s+$/, '') }))
      },
      findRow,
    }
  } catch {
    return null
  }
}

/** Run a read against a knowledge pack. */
export function runRead(packRoot: string, opts: ReadOptions): ReadResult {
  const docIds = (Array.isArray(opts.docId) ? opts.docId : [opts.docId])
    .map((d) => d.trim())
    .filter((d) => d.length > 0)
  const tokens = opts.tokens ? ftsTokens(opts.tokens) : []
  const idx = openIndex(packRoot)
  // Only warn when the INDEXED path actually serves the pack: a pack without
  // line_text is read from files (physical doc.md lines — correct), so the
  // stale-index warning would be a false alarm there.
  const warning = idx ? packIndexWarning(packRoot) : undefined

  const result: ReadResult = {
    tool: 'kbtool',
    cmd: 'read',
    tokens: tokens.slice(0, 10),
    docs: [],
    ...(warning ? { warning } : {}),
  }
  const finalize = (): ReadResult => {
    if (idx) idx.conn.close()
    return result
  }

  // --sections mode: document map (per requested doc_id).
  if (opts.sections) {
    for (const docId of docIds) {
      if (idx) {
        const totalLines = idx.totalLinesOf(docId)
        if (totalLines === 0) {
          result.docs.push({ doc_id: docId, error: 'Document not found' })
          continue
        }
        const sections = sectionsFromTitleRows(idx.titleRows(docId), totalLines)
        result.docs.push({
          doc_id: docId,
          mode: 'sections',
          total_lines: totalLines,
          section_count: sections.length,
          sections: sections.slice(0, 200),
          ...(sections.length > 200 ? { truncated: true } : {}),
        })
      } else {
        const docPath = resolveDocPath(packRoot, docId)
        if (!docPath) {
          result.docs.push({ doc_id: docId, error: 'Document not found' })
          continue
        }
        const body = readFileSync(docPath, 'utf8')
        const sections = sectionsFromLines(body.split('\n'))
        result.docs.push({
          doc_id: docId,
          mode: 'sections',
          total_lines: body.split('\n').length,
          section_count: sections.length,
          sections: sections.slice(0, 200),
          ...(sections.length > 200 ? { truncated: true } : {}),
        })
      }
    }
    return finalize()
  }

  // Normal read mode.
  for (const docId of docIds) {
    if (idx) {
      const totalLines = idx.totalLinesOf(docId)
      if (totalLines === 0) {
        result.docs.push({ doc_id: docId, error: 'Document not found' })
        continue
      }
      let readLines: Array<{ line: number; text: string; hits: number }> = []
      let readMode = 'range'

      if (opts.around && opts.around > 0) {
        readMode = 'around'
        const targetLine = opts.around
        if (targetLine > totalLines) {
          result.docs.push({ doc_id: docId, mode: 'around', error: `line ${targetLine} out of range (total ${totalLines})` })
          continue
        }
        const titles = idx.titleRows(docId)
        const sections = sectionsFromTitleRows(titles, totalLines)
        let secStart = 1
        let secEnd = totalLines
        if (sections.length > 0) {
          const section = sectionContaining(sections, targetLine)
          if (section) {
            secStart = section.line
            secEnd = section.end_line
          } else {
            // Pre-heading region (frontmatter / doc intro before the first
            // title): read that region only, not the whole document.
            secStart = 1
            secEnd = sections[0]!.line - 1
          }
        }
        const expand = Math.max(0, opts.expand ?? 0)
        if (expand > 0 && sections.length > 0) {
          const secIdx = sections.findIndex((s) => s.line === secStart && s.end_line === secEnd)
          if (secIdx !== -1) {
            const a = sections[Math.max(0, secIdx - expand)]
            const b = sections[Math.min(sections.length - 1, secIdx + expand)]
            if (a) secStart = a.line
            if (b) secEnd = b.end_line
          }
        }
        // Oversized section: keep the requested target line inside the window
        // (never silently drop it by taking the section prefix) — decided by
        // arithmetic BEFORE reading, never by materializing the full section.
        const secLen = secEnd - secStart + 1
        if (secLen > MAX_READ_LINES) {
          const half = Math.floor(MAX_READ_LINES / 2)
          readLines = idx.rangeRead(docId, Math.max(1, targetLine - half), MAX_READ_LINES).map((l) => ({ ...l, hits: 0 }))
        } else {
          readLines = idx.rangeRead(docId, secStart, secLen).map((l) => ({ ...l, hits: 0 }))
        }
      } else if (opts.find) {
        readMode = 'find'
        const findLower = opts.find.toLowerCase()
        const afterLine = Math.max(0, opts.after ?? 0) // 1-based; rows strictly after it
        const hitLine = idx.findRow(docId, afterLine, findLower)
        if (hitLine === null) {
          result.docs.push({ doc_id: docId, mode: 'find', find: opts.find, after: afterLine, found: false })
          continue
        }
        const context = opts.expand ?? 10
        const ctxStart = Math.max(1, hitLine.line_number - context)
        readLines = idx.rangeRead(docId, ctxStart, Math.min(context * 2 + 1, MAX_READ_LINES)).map((l) => ({ ...l, hits: 0 }))
      } else if (opts.jump) {
        readMode = 'jump'
        let budget = MAX_READ_LINES
        let invalid: string[] = []
        for (const part of opts.jump.split(',')) {
          const p = part.trim()
          if (!p) continue
          if (budget <= 0) break
          if (p.includes('-')) {
            const [aRaw, bRaw] = p.split('-', 2)
            const a = Number(aRaw)
            const b = Number(bRaw)
            if (!Number.isInteger(a) || !Number.isInteger(b) || a < 1 || b < a) {
              invalid.push(p)
              continue
            }
            const n = Math.min(b - a + 1, budget)
            readLines.push(...idx.rangeRead(docId, a, n).map((l) => ({ ...l, hits: 0 })))
            budget -= n
          } else {
            const a = Number(p)
            if (!Number.isInteger(a) || a < 1) {
              invalid.push(p)
              continue
            }
            const n = Math.min(opts.count ?? 20, budget)
            readLines.push(...idx.rangeRead(docId, a, n).map((l) => ({ ...l, hits: 0 })))
            budget -= n
          }
        }
        if (invalid.length > 0) {
          result.docs.push({ doc_id: docId, mode: 'jump', error: `invalid ranges: ${invalid.join(', ')}`, lines: readLines })
          continue
        }
      } else {
        readMode = 'range'
        const start = Math.max(1, opts.start ?? 1)
        const count = Math.min(opts.count ?? 20, MAX_READ_LINES)
        if (start > totalLines) {
          result.docs.push({ doc_id: docId, mode: 'range', error: `start ${start} out of range (total ${totalLines})` })
          continue
        }
        readLines = idx.rangeRead(docId, start, count).map((l) => ({ ...l, hits: 0 }))
      }

      markHits(readLines, tokens)
      const totalHits = readLines.reduce((acc, l) => acc + l.hits, 0)
      const hitLines = readLines.filter((l) => l.hits > 0).map((l) => l.line)
      result.docs.push({
        doc_id: docId,
        mode: readMode,
        total_lines: totalLines,
        read_lines: readLines.length,
        total_token_hits: totalHits,
        hit_lines: hitLines.slice(0, 30),
        lines: readLines,
      })
    } else {
      result.docs.push(readLegacyDoc(packRoot, docId, opts, tokens))
    }
  }
  return finalize()
}

/** Legacy file-based read (Python-built packs without line_text). Shares the
 * indexed path's semantics: title-row sections, pre-heading region handling,
 * and identical out-of-range / invalid-range errors. */
function readLegacyDoc(packRoot: string, docId: string, opts: ReadOptions, tokens: string[]): ReadDoc {
  const docPath = resolveDocPath(packRoot, docId)
  if (!docPath) return { doc_id: docId, error: 'Document not found' }
  const body = readFileSync(docPath, 'utf8')
  const lines = body.split('\n')
  const totalLines = lines.length
  let readLines: Array<{ line: number; text: string; hits: number }> = []
  let readMode = 'range'

  if (opts.around && opts.around > 0) {
    readMode = 'around'
    const targetLine = opts.around
    if (targetLine > totalLines) {
      return { doc_id: docId, mode: 'around', error: `line ${targetLine} out of range (total ${totalLines})` }
    }
    const sections = sectionsFromLines(lines)
    let secStart = 1
    let secEnd = totalLines
    if (sections.length > 0) {
      const section = sectionContaining(sections, targetLine)
      if (section) {
        secStart = section.line
        secEnd = section.end_line
      } else {
        secStart = 1
        secEnd = sections[0]!.line - 1
      }
    }
    const expand = Math.max(0, opts.expand ?? 0)
    if (expand > 0 && sections.length > 0) {
      const secIdx = sections.findIndex((s) => s.line === secStart && s.end_line === secEnd)
      if (secIdx !== -1) {
        const a = sections[Math.max(0, secIdx - expand)]
        const b = sections[Math.min(sections.length - 1, secIdx + expand)]
        if (a) secStart = a.line
        if (b) secEnd = b.end_line
      }
    }
    if (secEnd - secStart + 1 > MAX_READ_LINES) {
      const half = Math.floor(MAX_READ_LINES / 2)
      readLines = readRange(lines, Math.max(1, targetLine - half), MAX_READ_LINES)
    } else {
      readLines = readRange(lines, secStart, secEnd - secStart + 1)
    }
  } else if (opts.find) {
    readMode = 'find'
    const findLower = opts.find.toLowerCase()
    const afterLine = Math.max(0, opts.after ?? 0)
    const context = opts.expand ?? 10
    let found = false
    for (let i = afterLine; i < totalLines; i++) {
      if ((lines[i] ?? '').toLowerCase().includes(findLower)) {
        const matchLine = i + 1
        const ctxStart = Math.max(1, matchLine - context)
        readLines = readRange(lines, ctxStart, Math.min(context * 2 + 1, MAX_READ_LINES))
        found = true
        break
      }
    }
    if (!found) return { doc_id: docId, mode: 'find', find: opts.find, after: afterLine, found: false }
  } else if (opts.jump) {
    readMode = 'jump'
    let budget = MAX_READ_LINES
    let invalid: string[] = []
    for (const part of opts.jump.split(',')) {
      const p = part.trim()
      if (!p || budget <= 0) continue
      if (p.includes('-')) {
        const [aRaw, bRaw] = p.split('-', 2)
        const a = Number(aRaw)
        const b = Number(bRaw)
        if (!Number.isInteger(a) || !Number.isInteger(b) || a < 1 || b < a) {
          invalid.push(p)
          continue
        }
        const n = Math.min(b - a + 1, budget)
        for (const ln of readRange(lines, a, n)) readLines.push(ln)
        budget -= n
      } else {
        const a = Number(p)
        if (!Number.isInteger(a) || a < 1) {
          invalid.push(p)
          continue
        }
        const n = Math.min(opts.count ?? 20, budget)
        for (const ln of readRange(lines, a, n)) readLines.push(ln)
        budget -= n
      }
    }
    if (invalid.length > 0) {
      return { doc_id: docId, mode: 'jump', error: `invalid ranges: ${invalid.join(', ')}`, lines: readLines }
    }
    readLines = readLines.slice(0, MAX_READ_LINES)
  } else {
    readMode = 'range'
    const start = Math.max(1, opts.start ?? 1)
    const count = Math.min(opts.count ?? 20, MAX_READ_LINES)
    if (start > totalLines) {
      return { doc_id: docId, mode: 'range', error: `start ${start} out of range (total ${totalLines})` }
    }
    readLines = readRange(lines, start, count)
  }

  markHits(readLines, tokens)
  const totalHits = readLines.reduce((acc, l) => acc + l.hits, 0)
  const hitLines = readLines.filter((l) => l.hits > 0).map((l) => l.line)
  return {
    doc_id: docId,
    mode: readMode,
    total_lines: totalLines,
    read_lines: readLines.length,
    total_token_hits: totalHits,
    hit_lines: hitLines.slice(0, 30),
    lines: readLines,
  }
}
