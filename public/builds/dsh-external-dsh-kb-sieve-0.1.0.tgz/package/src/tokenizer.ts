/**
 * Canonical tokenization core — faithful TS port of the original Python
 * `tokenizer_core.py` (the SINGLE source of truth for both build-time
 * indexing and runtime query tokenization in the Python kb-sieve).
 *
 * CJK runs → overlapping 2/3/4-grams (+ full word for 2-6 char runs); ASCII
 * words `[A-Za-z0-9_]{2,}` lowercased; full-width punctuation mapped to
 * ASCII before tokenization; CJK/EN stop words filtered at query time.
 *
 * @module @dsh-external/dsh-kb-sieve/tokenizer
 */

import { createHash } from 'node:crypto'

/** Complete Unicode 15.1 CJK Unified Ideograph ranges (Extensions A–I + compatibility). */
const CJK_RANGES: ReadonlyArray<readonly [number, number]> = [
  [0x4E00, 0x9FFF], // CJK Unified Ideographs (most frequent — checked first)
  [0x3400, 0x4DBF], // Extension A
  [0xF900, 0xFAFF], // Compatibility Ideographs
  [0x20000, 0x2A6DF], // Extension B
  [0x2A700, 0x2B73F], // Extension C
  [0x2B740, 0x2B81F], // Extension D
  [0x2B820, 0x2CEAF], // Extension E
  [0x2CEB0, 0x2EBEF], // Extension F
  [0x2EBF0, 0x2EE5F], // Extension I
  [0x30000, 0x3134F], // Extension G
  [0x31350, 0x323AF], // Extension H
  [0x2F800, 0x2FA1F], // Compatibility Supplement
]

/** Char class of CJK + 0-9a-z, used by normalize_alias_text. */
const CJK_RE_CHAR_CLASS =
  '0-9a-z' +
  '\\u3400-\\u4DBF' +
  '\\u4E00-\\u9FFF' +
  '\\uF900-\\uFAFF' +
  '\\u{20000}-\\u{2A6DF}' +
  '\\u{2A700}-\\u{2B73F}' +
  '\\u{2B740}-\\u{2B81F}' +
  '\\u{2B820}-\\u{2CEAF}' +
  '\\u{2CEB0}-\\u{2EBEF}' +
  '\\u{2EBF0}-\\u{2EE5F}' +
  '\\u{30000}-\\u{3134F}' +
  '\\u{31350}-\\u{323AF}' +
  '\\u{2F800}-\\u{2FA1F}'

/** Whether *ch* is a CJK unified or compatibility ideograph. */
export function isCjk(ch: string): boolean {
  const o = ch.codePointAt(0) ?? 0
  if (o >= 0x4E00 && o <= 0x9FFF) return true
  return CJK_RANGES.slice(1).some(([lo, hi]) => o >= lo && o <= hi)
}

/** Max length of a CJK run emitted as a full-word token in addition to its n-grams. */
const MAX_SHORT_WORD_LEN = 6

const ASCII_WORD_RE = /[A-Za-z0-9_]{2,}/g

/** Full-width punctuation → ASCII, before tokenization (1:1 positional map). */
const CJK_PUNCT_MAP: Readonly<Record<string, string>> = {
  '，': ',', '、': ',', '：': ':', '；': ';',
  '（': '(', '）': ')', '「': '[', '」': ']', '『': '[', '』': ']', '【': '[', '】': ']',
  '《': '《', '》': '》', '〈': '〈', '〉': '〉', '…': '…', '——': '——', '～': '~', '·': '·',
}

function translatePunct(text: string): string {
  let out = ''
  for (const ch of text) {
    out += CJK_PUNCT_MAP[ch] ?? ch
  }
  return out
}

/** Tokenize a CJK run into full word (2-6) + deduplicated overlapping 2/3/4-grams. */
export function tokenizeCjkNgram(text: string): string[] {
  const tokens: string[] = []
  let run: string[] = []

  const flush = (): void => {
    const n = run.length
    if (n === 0) return
    const seen = new Set<string>()
    if (n >= 2 && n <= MAX_SHORT_WORD_LEN) {
      const full = run.join('')
      tokens.push(full)
      seen.add(full)
    }
    if (n >= 2) {
      for (const gramLen of [2, 3, 4]) {
        if (gramLen > n) break
        for (let i = 0; i <= n - gramLen; i++) {
          const gram = run.slice(i, i + gramLen).join('')
          if (!seen.has(gram)) {
            seen.add(gram)
            tokens.push(gram)
          }
        }
      }
    } else if (n === 1) {
      tokens.push(run[0]!)
    }
    run = []
  }

  for (const ch of text) {
    if (isCjk(ch)) {
      run.push(ch)
    } else {
      flush()
    }
  }
  flush()
  return tokens
}

/** The CJK stop-word set (ported verbatim from the original). */
const CJK_STOP_WORDS = new Set([
  '的', '了', '在', '是', '有', '和', '就', '不', '都', '也',
  '着', '与', '及', '等', '或', '但', '而', '为', '以', '于',
  '被', '把', '让', '给', '向', '从', '对', '将', '还', '只',
  '又', '再', '更', '最', '之', '地', '得',
  '我', '你', '他', '她', '它', '我们', '你们', '他们', '她们', '它们',
  '自己', '大家', '别人',
  '什么', '怎么', '为什么', '哪里', '谁', '多少', '怎样', '如何', '何时',
  '因为', '所以', '因此', '于是', '但是', '然而', '不过',
  '如果', '那么', '虽然', '尽管', '即使', '除非', '除了',
  '无论', '不管', '不论', '而且', '并且', '以及', '或者', '还是',
  '否则', '不然', '不但', '不仅', '因而', '从而',
  '关于', '对于', '至于', '由于', '鉴于', '基于',
  '可以', '可能', '应该', '能够', '需要', '必须',
  '不可', '不能', '不会', '不得', '不要', '不必',
  '没有', '未', '别',
  '这', '那', '这个', '那个', '这些', '那些', '这样', '那样',
  '如此', '一些', '其',
  '很', '太', '非常', '十分',
  '已经', '正在', '曾经', '现在', '然后', '以后', '之后', '之前',
  '一直', '始终',
  '起来', '下去', '出来', '过去', '下来', '上去', '进来',
  '便', '却', '到', '会', '要', '能',
  '跟', '同', '并', '按', '当', '比',
  '为了', '作为', '第',
])

/** The EN stop-word set (ported verbatim from the original). */
const EN_STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', "aren't",
  'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',
  "can't", 'cannot', 'could', "couldn't", 'did', "didn't", 'do', 'does', "doesn't", 'doing', "don't",
  'down', 'during', 'each', 'few', 'for', 'from', 'further', 'had', "hadn't", 'has', "hasn't", 'have',
  "haven't", 'having', 'he', "he'd", "he'll", "he's", 'her', 'here', "here's", 'hers', 'herself',
  'him', 'himself', 'his', 'how', "how's", 'i', "i'd", "i'll", "i'm", "i've", 'if', 'in', 'into',
  'is', "isn't", 'it', "it's", 'its', 'itself', "let's", 'me', 'more', 'most', "mustn't", 'my',
  'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our',
  'ours', 'ourselves', 'out', 'over', 'own', 'same', "shan't", 'she', "she'd", "she'll", "she's",
  'should', "shouldn't", 'so', 'some', 'such', 'than', 'that', "that's", 'the', 'their', 'theirs',
  'them', 'themselves', 'then', 'there', "there's", 'these', 'they', "they'd", "they'll", "they're",
  "they've", 'this', 'those', 'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', "wasn't",
  'we', "we'd", "we'll", "we're", "we've", 'were', "weren't", 'what', "what's", 'when', "when's",
  'where', "where's", 'which', 'while', 'who', "who's", 'whom', 'why', "why's", 'with', "won't",
  'would', "wouldn't", 'you', "you'd", "you'll", "you're", "you've", 'your', 'yours', 'yourself',
  'yourselves', 'boy', 'can', 'day', 'first', 'get', 'good', 'great', 'just', 'know', 'like', 'long',
  'make', 'many', 'may', 'might', 'much', 'never', 'new', 'now', 'old', 'one', 'said', 'say', 'see',
  'shall', 'still', 'take', 'tell', 'think', 'time', 'try', 'two', 'use', 'want', 'way', 'well', 'will',
])

/** Full tokenization: punctuation normalization + CJK ngrams + ASCII words, minus stop words. */
export function ftsTokens(text: string): string[] {
  const translated = translatePunct(text)
  const tokens: string[] = []
  for (const t of tokenizeCjkNgram(translated)) tokens.push(t)
  for (const m of translated.matchAll(ASCII_WORD_RE)) {
    tokens.push(m[0].toLowerCase())
  }
  // Query-time stop-word filtering: safe because the index remains complete.
  return tokens.filter((t) => !CJK_STOP_WORDS.has(t) && !EN_STOP_WORDS.has(t))
}

/** Build `"tok1" OR "tok2"…` clauses, quoted/escaped, deduped, capped at maxTokens. */
function buildMatchClauses(tokens: readonly string[], maxTokens: number): string[] {
  const safe: string[] = []
  const seen = new Set<string>()
  for (const t of tokens) {
    const escaped = t.replaceAll('"', '""')
    if (!escaped || seen.has(escaped)) continue
    seen.add(escaped)
    safe.push(`"${escaped}"`)
    if (safe.length >= maxTokens) break
  }
  return safe
}

/** OR of quoted tokens (default query). */
export function buildMatchQuery(tokens: readonly string[], maxTokens = 64): string {
  const clauses = buildMatchClauses(tokens, maxTokens)
  return clauses.join(' OR ')
}

/** AND of quoted tokens (per-term must-match). */
export function buildMatchAll(tokens: readonly string[], maxTokens = 16): string {
  const clauses = buildMatchClauses(tokens, maxTokens)
  return clauses.join(' AND ')
}

/** Split a raw query into whitespace-separated parts. */
export function queryTerms(rawQuery: string): string[] {
  const q = rawQuery.trim()
  if (!q) return []
  const parts = q.split(/\s+/).map((p) => p.trim()).filter((p) => p.length > 0)
  return parts.length > 0 ? parts : [q]
}

/** Build a full MATCH expression: optional must-terms + query mode (and/or). */
export function buildMatchExpression(
  rawQuery: string,
  opts: { queryMode: string; mustTerms: readonly string[]; maxTokens?: number },
): string {
  const mustClauses: string[] = []
  for (const t of opts.mustTerms) {
    const clause = buildMatchAll(ftsTokens(t))
    if (clause) mustClauses.push(clause.includes(' AND ') ? `(${clause})` : clause)
  }

  let queryClause = ''
  if (opts.queryMode === 'and') {
    const parts = queryTerms(rawQuery)
    const qClauses: string[] = []
    for (const p of parts) {
      const clause = buildMatchAll(ftsTokens(p))
      if (!clause) continue
      qClauses.push(clause.includes(' AND ') ? `(${clause})` : clause)
    }
    queryClause = qClauses.join(' AND ')
  } else {
    queryClause = buildMatchQuery(ftsTokens(rawQuery), opts.maxTokens ?? 64)
  }

  const clauses = [...mustClauses, ...(queryClause ? [queryClause] : [])].filter(Boolean)
  if (clauses.length === 0) return ''
  if (clauses.length === 1) return clauses[0] ?? ''
  return clauses.map((c) => (c.includes(' OR ') || c.includes(' AND ') ? `(${c})` : c)).join(' AND ')
}

/** Markdown → plain text (headings, inline code, links, emphasis stripped). */
export function markdownToPlain(md: string): string {
  const outLines: string[] = []
  for (const raw of md.split('\n')) {
    const line = raw.trim()
    if (!line) {
      outLines.push('')
      continue
    }
    let l = line.replace(/^#{1,6}\s+/, '')
    l = l.replace(/`([^`]*)`/g, '$1')
    l = l.replace(/\[(.*?)\]\((.*?)\)/g, '[$1]')
    l = l.replaceAll('**', '').replaceAll('__', '').replaceAll('*', '')
    outLines.push(l)
  }
  return outLines.join('\n').trim() + '\n'
}

/** Parse YAML frontmatter (line-level; robust to '---' inside values). */
export function parseFrontmatter(md: string): Record<string, string> {
  const lines = md.split('\n')
  if (lines.length === 0 || (lines[0] ?? '').trim() !== '---') return {}
  const fm: Record<string, string> = {}
  for (const line of lines.slice(1)) {
    if (line.trim() === '---') break
    const idx = line.indexOf(':')
    if (idx !== -1) {
      const k = line.slice(0, idx).trim()
      fm[k] = line.slice(idx + 1).trim().replace(/^"|"$/g, '')
    }
  }
  return fm
}

/** Strip YAML frontmatter (line-start `---` only; keeps line structure). */
export function stripFrontmatter(md: string): string {
  if (!md.startsWith('---')) return md
  let idx = 3
  for (;;) {
    const pos = md.indexOf('\n---', idx)
    if (pos === -1) return md
    const after = pos + 4
    if (after === md.length || md[after] === '\n') {
      return md.slice(after).replace(/^\r?\n/, '')
    }
    idx = pos + 1
  }
}

/** SHA-256 hex digest (64 chars). */
export function stableHash(text: string): string {
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

const VERSION_RE = /\bV(\d+)\b/i

/** Derive source_version from a title/name (`V<n>` → `v<n>`, else `current`). */
export function deriveSourceVersion(name: string, title: string): string {
  const match = VERSION_RE.exec(title) ?? VERSION_RE.exec(name)
  const num = match?.[1]
  if (num) return `v${num}`
  return 'current'
}

/** NFKC + lowercase + keep only CJK/ASCII alnum (identifier normalization). */
export function normalizeAliasText(text: string): string {
  const normalized = text.normalize('NFKC').toLowerCase()
  const re = new RegExp(`[^${CJK_RE_CHAR_CLASS}]+`, 'gu')
  return normalized.replace(re, '')
}
