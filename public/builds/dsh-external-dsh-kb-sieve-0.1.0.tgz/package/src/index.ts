/**
 * dsh-kb-sieve — 知识库筛子插件。
 *
 * 把文档（md/txt/docx/pdf）构建成可审计知识包（references/ + kb.sqlite FTS5），
 * 并提供确定性检索（kb_query）与原文精读（kb_read）两个运行时工具。纯计算，
 * 零子代理、零 workflow、零外部服务——inject 只需要工具注册服务。
 *
 * 生成的 skill 是纯数据（SKILL.md 指令 + references/ + kb.sqlite），零脚本零
 * Python；输出到监听中的 skill 根目录（当前项目根目录的 .dsh/skills）
 * 时，DSH 动态发现并加载，实现"安装即用"的知识库。
 *
 * Native TypeScript source: the package entry points at this file and no build
 * step exists. In a dsh profile the package lives under node_modules, so it
 * loads through the dsh source launcher's whole-process tsx hook (Node's
 * native type stripping refuses files under node_modules); a checkout run
 * outside node_modules can also load via Node >=22.18 native stripping.
 * Syntax must stay erasable-only (no enums/namespaces/parameter properties).
 *
 * @module @dsh-external/dsh-kb-sieve
 */

import { existsSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { Context } from 'cordis'
import { buildSkill, type BuildResult } from './build.ts'
import { runQuery, type QueryResult } from './query.ts'
import { runRead, type ReadResult } from './read.ts'

export const name = 'dsh-kb-sieve'

/** Activate once the tool registry is available. */
export const inject = ['tools']

/** Loader-validated plugin config (all keys optional). */
export interface Config {
  /** Default output parent for kb_build (the pack lands in `<defaultOutDir>/<name>`). */
  defaultOutDir?: string
}

/** kb_build tool result. */
interface BuildOutcome {
  ok: boolean
  skill_root: string
  skill_name: string
  doc_count: number
  doc_ids: string[]
  errors: string[]
}

/** Resolve the default skill output root: always the CURRENT PROJECT ROOT —
 * <nearest .git>/.dsh/skills, else <cwd>/.dsh/skills. Never falls back to
 * the user's home (~/.dsh/skills): users expect the knowledge base to land
 * in the working directory's project, and DSH discovers project-level
 * .dsh/skills wherever the session runs. Exported for tests. */
export function resolveDefaultOutDir(): string {
  let dir = process.cwd()
  for (;;) {
    if (existsSync(join(dir, '.git'))) return join(dir, '.dsh', 'skills')
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  return join(process.cwd(), '.dsh', 'skills')
}

/** Resolve a caller-supplied path against the process cwd. */
function resolvePath(p: string): string {
  return resolve(p)
}

/** Apply the plugin: register kb_build / kb_query / kb_read. */
export function apply(ctx: Context, config: Config = {}) {
  const defaultOutDir = config.defaultOutDir !== undefined && config.defaultOutDir.length > 0
    ? resolvePath(config.defaultOutDir)
    : resolveDefaultOutDir()

  ctx.tools.register(defineTool({
    name: 'kb_build',
    description:
      '构建知识库：把一组文档（.md/.txt/.docx/.pdf）做成可审计知识包——references/<doc_id>/doc.md 原文'
      + '+ kb.sqlite（SQLite FTS5 整文档索引，无向量无外部依赖）+ manifest.json + SKILL.md。'
      + '默认输出到当前项目根目录的 .dsh/skills/<name>/（最近的 .git 目录或当前工作目录之下）——'
      + '监听中的 skill 根目录会被 DSH 动态发现，模型下一轮即可通过 skill 目录加载该知识库。'
      + '触发场景：用户要求把若干文档整理成可检索的知识库/规范库/手册、或要求"记住这些文档"。'
      + '构建是确定性的：同样的输入产出同样的产物（chunking 参数固定，无 LLM 参与）。',
    parameters: {
      name: {
        type: 'string',
        required: true,
        description: '知识库名（skill 名）：小写字母/数字/连字符，如 my-books。',
      },
      inputs: {
        type: 'array',
        required: true,
        items: { type: 'string' },
        description: '输入文档路径列表（相对当前工作目录或绝对路径；.md/.txt/.docx/.pdf）。',
      },
      out: {
        type: 'string',
        description: '可选：输出父目录（知识包落在 <out>/<name>/）；缺省为当前项目根目录的 .dsh/skills（最近的 .git 或当前工作目录）。',
      },
      title: {
        type: 'string',
        description: '可选：知识库显示标题（默认取第一份文档标题）。',
      },
      force: {
        type: 'boolean',
        description: '可选：true = 全量重建；false/缺省 = 有 build_state 时自动增量（新增/修改/删除/不变四态）。',
      },
      workers: {
        type: 'number',
        description: '可选：抽取并发数（默认 4，最大 8）——并发越高内存峰值越高，内存紧张时调小。',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ok: { type: 'boolean', required: true },
          skill_root: { type: 'string', required: true },
          skill_name: { type: 'string', required: true },
          doc_count: { type: 'number', required: true },
          doc_ids: { type: 'array', required: true, items: { type: 'string' } },
          errors: { type: 'array', required: true, items: { type: 'string' } },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.ok
          ? `知识库已构建：${value.skill_root}（${value.doc_count} 份文档）\n`
            + `doc_ids: ${value.doc_ids.join(', ')}`
            + (value.errors.length > 0 ? `\n部分输入失败：\n${value.errors.join('\n')}` : '')
          : `kb_build 未能完成：${value.skill_root}`,
      }],
    },
    async execute(args): Promise<BuildOutcome> {
      const name = String(args.name).trim()
      const inputs = (args.inputs ?? []).map((p) => String(p).trim()).filter((p) => p.length > 0)
      const outDir = args.out !== undefined && String(args.out).trim().length > 0
        ? resolvePath(String(args.out))
        : defaultOutDir
      const result: BuildResult = await buildSkill({
        skillName: name,
        title: args.title !== undefined ? String(args.title) : name,
        inputs,
        outDir,
        force: args.force === true,
        ...(typeof args.workers === 'number' ? { workers: args.workers } : {}),
      })
      return {
        ok: true,
        skill_root: result.skillRoot,
        skill_name: result.skillName,
        doc_count: result.docCount,
        doc_ids: result.docIds,
        errors: result.errors,
      }
    },
  }))

  ctx.tools.register(defineTool({
    name: 'kb_query',
    description:
      '知识库检索：对知识包（kb_build 的产物）做确定性全文检索——FTS5 BM25 + 精确标识符匹配'
      + '（标准号/章节号/型号）+ 文档类型加权 + 窗口密度重排，返回 doc_id + 行号 + 匹配行 + score + status。'
      + 'status: high_confidence / needs_verification / no_hits；越界查询（库中不存在的标准号/型号，'
      + '或绝大多数词不在语料域内）返回 no_hits + oos_reason。'
      + '用法：先用 kb_query 定位证据（doc_id + line），再用 kb_read 精读原文；'
      + '行号是内部定位用的虚拟行号，回答引用一律用章节名（如"第 D21.3 节"），不要向用户输出行号；'
      + '答案必须引用 references/ 原文，禁止凭记忆回答。多跳问题分轮检索，每轮 1-2 个关键词。',
    parameters: {
      pack: {
        type: 'string',
        required: true,
        description: '知识包路径（kb_build 输出的 skill_root）。',
      },
      query: {
        type: 'string',
        required: true,
        description: '查询词/问题（支持标准号、章节号、关键词组合）。',
      },
      limit: {
        type: 'number',
        description: '可选：返回文档数上限（默认 10，最大 100）。',
      },
      doc_ids: {
        type: 'string',
        description: '可选：限定检索范围，逗号分隔的 doc_id 列表。',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          tool: { type: 'string', required: true },
          cmd: { type: 'string', required: true },
          query: { type: 'string', required: true },
          status: { type: 'string', required: true },
          fts_match: { type: 'string', required: true },
          results: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                file: { type: 'string', required: true },
                doc_id: { type: 'string', required: true },
                title: { type: 'string', required: true },
                score: { type: 'number', required: true },
                matches: {
                  type: 'array',
                  required: true,
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    properties: {
                      line: { type: 'number', required: true },
                      text: { type: 'string', required: true },
                    },
                  },
                },
              },
            },
          },
          next_action: { type: 'string', required: true },
          oos_reason: { type: 'string' },
          error: { type: 'string' },
          warning: { type: 'string' },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: JSON.stringify(value, null, 2),
      }],
    },
    async execute(args): Promise<QueryResult> {
      const pack = resolvePath(String(args.pack))
      const docIds = typeof args.doc_ids === 'string' && args.doc_ids.trim().length > 0
        ? args.doc_ids.split(',').map((d) => d.trim()).filter((d) => d.length > 0).slice(0, 200)
        : undefined
      const limit = typeof args.limit === 'number' ? Math.max(1, Math.min(100, Math.floor(args.limit))) : undefined
      return runQuery(pack, String(args.query), {
        ...(limit !== undefined ? { limit } : {}),
        ...(docIds && docIds.length > 0 ? { docIds } : {}),
      })
    },
  }))

  ctx.tools.register(defineTool({
    name: 'kb_read',
    description:
      '知识库原文精读：按 doc_id + 行号精读知识包里的原文段落，自动定位章节边界并标记命中词。'
      + '模式：around=行号（读该行所在完整章节；expand=N 扩展相邻章节）；sections=true（文档地图：'
      + '章节标题+行号）；find=关键词（从 after 行向后搜索并返回上下文）；jump="210-230,450-460"'
      + '（跳读多段）；start/count（范围读取）。tokens=关键词 时输出每行命中数。'
      + '用法：从 kb_query 结果取 doc_id 和 line，调用本工具精读原文后再回答；'
      + '行号仅用于本工具定位，回答时引用章节名而非行号；禁止凭记忆补全。',
    parameters: {
      pack: {
        type: 'string',
        required: true,
        description: '知识包路径（kb_build 输出的 skill_root）。',
      },
      doc_id: {
        type: 'string',
        required: true,
        description: '文档标识（kb_query 结果中的 doc_id；逗号分隔可多文档）。',
      },
      tokens: {
        type: 'string',
        description: '可选：关键词（命中标记，空格分隔）。',
      },
      sections: {
        type: 'boolean',
        description: '可选：true = 输出文档章节地图（标题+行号）。',
      },
      around: {
        type: 'number',
        description: '可选：精读该行所在的完整章节。',
      },
      expand: {
        type: 'number',
        description: '可选：around 时扩展相邻章节数；find 时作为上下文行数（默认 10）。',
      },
      find: {
        type: 'string',
        description: '可选：从 after 行向后搜索关键词并返回上下文。',
      },
      after: {
        type: 'number',
        description: '可选：find 的起始行（0-based，默认 0）。',
      },
      jump: {
        type: 'string',
        description: '可选：跳读多段，如 "210-230,450-460"。',
      },
      start: {
        type: 'number',
        description: '可选：范围读取起始行（默认 1）。',
      },
      count: {
        type: 'number',
        description: '可选：范围读取行数（默认 20）。',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          tool: { type: 'string', required: true },
          cmd: { type: 'string', required: true },
          tokens: { type: 'array', required: true, items: { type: 'string' } },
          warning: { type: 'string' },
          docs: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                doc_id: { type: 'string', required: true },
                mode: { type: 'string' },
                total_lines: { type: 'number' },
                read_lines: { type: 'number' },
                total_token_hits: { type: 'number' },
                hit_lines: { type: 'array', items: { type: 'number' } },
                error: { type: 'string' },
                found: { type: 'boolean' },
                sections: {
                  type: 'array',
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    properties: {
                      line: { type: 'number', required: true },
                      end_line: { type: 'number', required: true },
                      heading: { type: 'string', required: true },
                      line_count: { type: 'number', required: true },
                    },
                  },
                },
                lines: {
                  type: 'array',
                  items: {
                    type: 'object',
                    additionalProperties: false,
                    properties: {
                      line: { type: 'number', required: true },
                      text: { type: 'string', required: true },
                      hits: { type: 'number', required: true },
                    },
                  },
                },
              },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: JSON.stringify(value, null, 2),
      }],
    },
    async execute(args): Promise<ReadResult> {
      const pack = resolvePath(String(args.pack))
      const docIds = String(args.doc_id).split(',').map((d) => d.trim()).filter((d) => d.length > 0)
      if (docIds.length === 0) throw new Error('kb_read: doc_id required')
      return runRead(pack, {
        docId: docIds,
        ...(typeof args.tokens === 'string' ? { tokens: args.tokens } : {}),
        ...(args.sections === true ? { sections: true } : {}),
        ...(typeof args.around === 'number' ? { around: args.around } : {}),
        ...(typeof args.expand === 'number' ? { expand: args.expand } : {}),
        ...(typeof args.find === 'string' ? { find: args.find } : {}),
        ...(typeof args.after === 'number' ? { after: args.after } : {}),
        ...(typeof args.jump === 'string' ? { jump: args.jump } : {}),
        ...(typeof args.start === 'number' ? { start: args.start } : {}),
        ...(typeof args.count === 'number' ? { count: args.count } : {}),
      })
    },
  }))
}
