/**
 * Heading detection — the SINGLE source of truth for what counts as a
 * section heading line.
 *
 * The decision is materialized at build time (line_text.is_heading), so
 * query-time section maps are index point-reads (`WHERE is_heading = 1`)
 * instead of scanning every line with a SQL approximation of a JS regex.
 * The legacy file path (index-less packs) uses the same function, so both
 * paths agree line-for-line by construction.
 *
 * @module @dsh-external/dsh-kb-sieve/heading
 */

const HEADING_RE = /^#{1,6}\s/
/** Numbered sections: 第X章/节/回 (CJK digits or arabic digits) or dotted
 * numbers ('1.1.1 Intro' — at least one dot, then whitespace, so '1. item'
 * list rows and bare page numbers never match). Kept byte-identical to the
 * Python original's section markers (contract). */
const NUM_SECTION_RE = /^#{0,2}\s*(?:第[一二三四五六七八九十百千\d]+[章节回]|[0-9]+(?:\.[0-9]+)+\s)/

/** Whether a line is a section heading. Leading whitespace is stripped
 * first (trim() semantics: any JS whitespace), matching how both the
 * indexed and legacy paths have always classified lines. */
export function isHeadingLine(text: string): boolean {
  const t = text.trim()
  return HEADING_RE.test(t) || NUM_SECTION_RE.test(t)
}
