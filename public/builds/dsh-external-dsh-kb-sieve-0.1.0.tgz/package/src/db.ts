/**
 * SQLite schema + build-time write path — faithful port of the Python
 * `db/schema.py` + `db/crud.py`. Whole-document mode: `docs` (tokenized body)
 * + external-content FTS5 `doc_fts` (fts_title, body) + `line_offsets`.
 *
 * @module @dsh-external/dsh-kb-sieve/db
 */

import { DatabaseSync } from 'node:sqlite'
import { ftsTokens } from './tokenizer.ts'
import { isHeadingLine } from './heading.ts'

export interface DocRecord {
  docId: string
  docTitle: string
  sourceFile: string
  sourcePath: string
  docHash: string
  sourceVersion: string
  isActive: boolean
  /** Pre-tokenized FTS body (space-joined tokens). */
  body: string
  /** FULL doc.md text — the line-number base (physical doc.md lines). */
  bodyText: string
  /** Original document line count (density short-doc branch semantics). */
  canonicalLineCount: number
}

const SCHEMA_SCRIPT = `
CREATE TABLE IF NOT EXISTS docs (
  doc_row_id INTEGER PRIMARY KEY AUTOINCREMENT,
  doc_id TEXT NOT NULL,
  doc_title TEXT NOT NULL,
  source_file TEXT NOT NULL,
  source_path TEXT NOT NULL,
  doc_hash TEXT NOT NULL,
  source_version TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  line_count INTEGER NOT NULL DEFAULT 0,
  body TEXT,
  fts_title TEXT,
  UNIQUE (doc_id, source_version)
);

`

const INDEX_SCRIPT = `
CREATE INDEX IF NOT EXISTS idx_docs_doc_id_active ON docs(doc_id, is_active);
CREATE INDEX IF NOT EXISTS idx_line_text_doc ON line_text(doc_id, source_version);
CREATE INDEX IF NOT EXISTS idx_line_text_doc_line ON line_text(doc_id, line_number);
CREATE INDEX IF NOT EXISTS idx_line_text_doc_heading ON line_text(doc_id, is_heading, line_number);
CREATE INDEX IF NOT EXISTS idx_line_rowmap_doc ON line_rowmap(doc_id, source_version);
`

// ── 行级二级索引（性能）：行匹配与密度不再读 references 全文 ──────────────
// line_text:  原文行，按 (doc_id, line_number) 主键读取（行匹配 SQL 子串扫描）
// line_fts:   contentless FTS5（只存 [a-z]+ 词索引，不存内容）——密度专用
// line_rowmap: line_fts rowid → (doc_id, source_version, line_number) 显式映射，
//             增量删除后 rowid 出现空洞也保持正确（替代脆弱的 rowid 对齐）
// 存在 line_fts 表 = 新包；老包（原版 Python 产物）无此表 → 运行时回退全文扫描。

const LINE_INDEX_SCRIPT = `
CREATE TABLE IF NOT EXISTS line_text (
  doc_id TEXT NOT NULL,
  source_version TEXT NOT NULL,
  line_number INTEGER NOT NULL,
  text TEXT NOT NULL,
  text_lower TEXT,
  is_heading INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (doc_id, source_version, line_number)
);

-- Explicit line_fts rowid -> (doc_id, line_number) map: survives incremental
-- deletes (rowid holes) where the old implicit rowid alignment would break.
CREATE TABLE IF NOT EXISTS line_rowmap (
  rowid INTEGER PRIMARY KEY,
  doc_id TEXT NOT NULL,
  source_version TEXT NOT NULL,
  line_number INTEGER NOT NULL
);

-- Contentful (not contentless): FTS5 contentless tables forbid DELETE, and
-- incremental rebuilds must delete stale doc rows by rowid.
CREATE VIRTUAL TABLE IF NOT EXISTS line_fts USING fts5(tokens);
`

/** Whether the pack has the line-level secondary index (new packs).
 * Keyed on line_text (the table the query/read paths actually read) so a
 * half-corrupt pack behaves identically in kb_query and kb_read. */
export function hasLineIndex(conn: DatabaseSync): boolean {
  const row = conn.prepare(
    "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'line_text'",
  ).get()
  return row !== undefined
}

/** Create an external-content FTS5 table over docs(fts_title, body). */
function createDocFts(conn: DatabaseSync): void {
  conn.exec(`
    CREATE VIRTUAL TABLE IF NOT EXISTS doc_fts USING fts5(
      fts_title, body,
      content='docs',
      content_rowid='doc_row_id'
    )
  `)
}

/** Open a kb.sqlite for writing (schema + pragmas applied). */
export function openKbForWrite(dbPath: string): DatabaseSync {
  const conn = new DatabaseSync(dbPath)
  conn.exec('PRAGMA journal_mode = WAL')
  conn.exec('PRAGMA synchronous = NORMAL')
  conn.exec('PRAGMA busy_timeout = 5000')
  conn.exec('PRAGMA temp_store = MEMORY')
  conn.exec('PRAGMA cache_size = -65536')
  conn.exec('PRAGMA mmap_size = 268435456')
  conn.exec(SCHEMA_SCRIPT)
  createDocFts(conn)
  conn.exec(LINE_INDEX_SCRIPT)
  ensureTextLowerColumn(conn)
  return conn
}

/**
 * Add the text_lower column to packs built before it existed. ALTER TABLE is
 * O(1) (schema-only); backfill is NOT done here — a pack whose index_version
 * is stale gets a full rebuild by buildSkill (every line rewritten with the
 * JS-lowercase text_lower), which also re-bases line numbers on the physical
 * doc.md. A failed ALTER is fatal (never leave a half-migrated schema).
 */
function ensureTextLowerColumn(conn: DatabaseSync): void {
  const cols = conn.prepare('PRAGMA table_info(line_text)').all() as Array<{ name: string }>
  if (!cols.some((c) => c.name === 'text_lower')) {
    conn.exec('ALTER TABLE line_text ADD COLUMN text_lower TEXT')
  }
}

/** Delete ALL versions of one document's live rows (docs/doc_fts/line_text/
 * line_rowmap). The doc_id is single-version in this pack model: a source
 * title version change (V1→V2) must not leave stale rows of the old version
 * (they would collide on line numbers and surface as duplicate matches).
 *
 * line_fts rows are KEPT as orphans: the rowmap no longer points at them, so
 * density JOINs and line matching (line_text) are unaffected; a full rebuild
 * (force) reclaims the index space. FTS5 row-at-a-time DELETE is far slower
 * than inserting the new rows, hence the orphan design. */
export function deleteDoc(conn: DatabaseSync, docId: string): void {
  conn.prepare('DELETE FROM line_rowmap WHERE doc_id = ?').run(docId)
  conn.prepare('DELETE FROM line_text WHERE doc_id = ?').run(docId)
  const rows = conn.prepare('SELECT doc_row_id FROM docs WHERE doc_id = ?').all(docId) as Array<{ doc_row_id: number }>
  const delFts = conn.prepare('DELETE FROM doc_fts WHERE rowid = ?')
  for (const r of rows) delFts.run(r.doc_row_id)
  conn.prepare('DELETE FROM docs WHERE doc_id = ?').run(docId)
}

/** Insert one document's rows (line index + docs + doc_fts), committing in
 * batches of 50K rows so WAL/journal memory stays bounded on huge docs.
 * Every line gets a line_fts row and a line_rowmap entry (explicit
 * rowid→(doc_id, line_number) mapping, robust to incremental deletes). */
/** Slice offset for a chunk boundary: keep the trailing chunk complete unless
 * the remainder is exhausted (avoids splitting mid-line numbering). */
export function writeDoc(conn: DatabaseSync, d: DocRecord): void {
  // Self-managed transaction, committed every BATCH rows so WAL/journal memory
  // stays bounded on huge docs; the caller must not wrap this in its own txn.
  // Line numbering follows docMd.split('\n') EXACTLY (trailing empty line
  // included): one physical doc.md line per row, no ghost rows.
  const BATCH = 50_000
  conn.exec('BEGIN')
  const insertDoc = conn.prepare(`
    INSERT INTO docs(
      doc_id, doc_title, source_file, source_path, doc_hash,
      source_version, is_active, line_count, body, fts_title
    ) VALUES (?,?,?,?,?,?,?,?,?,?)
  `)
  const insertLineText = conn.prepare(`
    INSERT INTO line_text(doc_id, source_version, line_number, text, text_lower, is_heading)
    VALUES (?,?,?,?,?,?)
  `)
  const insertLineFts = conn.prepare('INSERT INTO line_fts(tokens) VALUES (?)')
  const insertRowmap = conn.prepare(
    'INSERT INTO line_rowmap(rowid, doc_id, source_version, line_number) VALUES (?,?,?,?)',
  )

  const lineCount = d.canonicalLineCount
  insertDoc.run(
    d.docId, d.docTitle, d.sourceFile, d.sourcePath, d.docHash,
    d.sourceVersion, d.isActive ? 1 : 0, lineCount, d.body, ftsTokens(d.docTitle).join(' '),
  )

  // Iterate lines via indexOf('\n') — identical semantics to split('\n')
  // (trailing '' row included) without materializing an 866K-element array.
  let pos = 0
  let lineNum = 1
  let sinceBatch = 0
  for (;;) {
    const nl = d.bodyText.indexOf('\n', pos)
    const rowText = nl === -1 ? d.bodyText.slice(pos) : d.bodyText.slice(pos, nl)
    // is_heading materialized at build time (single authoritative JS regex,
    // see heading.ts) — query-time section maps are index point-reads.
    insertLineText.run(d.docId, d.sourceVersion, lineNum, rowText, rowText.toLowerCase(), isHeadingLine(rowText) ? 1 : 0)
    // line_fts serves ONLY window density: store the line's [a-z]+ word set
    // (the original census extracts words with [a-z]+), so glued alnum
    // tokens like GB50010-2010 expose their letter segments (gb).
    const words = [...new Set(rowText.toLowerCase().match(/[a-z]+/g) ?? [])].join(' ')
    const info = insertLineFts.run(words)
    insertRowmap.run(Number(info.lastInsertRowid), d.docId, d.sourceVersion, lineNum)
    lineNum += 1
    sinceBatch += 1
    if (sinceBatch >= BATCH) {
      conn.exec('COMMIT')
      conn.exec('BEGIN')
      sinceBatch = 0
    }
    if (nl === -1) break
    pos = nl + 1
  }

  // external-content FTS5: rowid must equal docs.doc_row_id.
  const row = conn.prepare('SELECT doc_row_id FROM docs WHERE doc_id = ? AND source_version = ?')
    .get(d.docId, d.sourceVersion) as { doc_row_id: number } | undefined
  if (row) {
    const ftsTitle = ftsTokens(d.docTitle).join(' ')
    if (ftsTitle || d.body) {
      conn.prepare('INSERT INTO doc_fts(rowid, fts_title, body) VALUES (?,?,?)')
        .run(row.doc_row_id, ftsTitle, d.body)
    }
  }
  conn.exec('COMMIT')
}

/** Finalize a write session: indexes + FTS optimize (call once per build). */
export function finalizeKb(conn: DatabaseSync): void {
  conn.exec(INDEX_SCRIPT)
  conn.exec("INSERT INTO doc_fts(doc_fts) VALUES('optimize')")
}

