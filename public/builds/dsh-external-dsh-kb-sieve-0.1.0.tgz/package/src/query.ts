/**
 * Query engine — faithful port of the Python `kbtool_lib/query_engine.py`.
 *
 * Pipeline: std-number rewrite → FTS5 BM25 (title=10/body=1) → exact
 * identifier match → category boost → window-density rerank → line-level
 * matching → out-of-domain gate (identifier miss / OOV ratio) → confidence.
 * Output shape mirrors the original compact payload.
 *
 * @module @dsh-external/dsh-kb-sieve/query
 */

import { readFileSync, realpathSync } from 'node:fs'
import { join, relative } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { ftsTokens, normalizeAliasText } from './tokenizer.ts'
import { hasLineIndex } from './db.ts'
import { INDEX_VERSION } from './constants.ts'

const WINDOW_SIZE_DEFAULT = 20
const WINDOW_SCAN_STEP = 5
const MIN_ASCII_TOKENS_FOR_WINDOW = 4
const MIN_IDENTIFIER_LEN = 4
const EXACT_MATCH_BOOST = -1.0
const MAX_MATCH_LINES = 10
const MIN_CONFIDENCE_HIGH = 0.62
const OOS_OOV_RATIO = 0.85

const CATEGORY_BOOST: Record<string, number> = {
  standard: 1.5,
  method: 1.3,
  regulation: 0.85,
  notice: 0.7,
  other: 1.0,
}

/** Document category from source file / doc_id (port of _doc_category). */
export function docCategory(sourceFile: string, docId: string): string {
  const lower = `${sourceFile ?? ''} ${docId ?? ''}`.toLowerCase()
  if (['gb ', 'gb/t ', 'jtg ', 'jtg/t ', 'jgj ', 'jgj/t ', 'cjj ', 'cjj/t ', 'jt/t ', 'jtt ', 'qb_', 'qb ', '规范', '规程', '标准', '工法']
    .some((p) => lower.includes(p))) return 'standard'
  if (['通知', '号文', '明白卡', '规定有关问题'].some((p) => lower.includes(p))) return 'notice'
  if (['令第', '管理条例', '管理办法', '监督办法', '安全生产法'].some((p) => lower.includes(p))) return 'regulation'
  return 'other'
}

/** Standard-number alias rewrites (JT/T → JTT etc.), port of the 8 regexes. */
function rewriteStdNumbers(rawQuery: string): string {
  const fixes: Array<[RegExp, string]> = [
    [/\bJT\s*\/\s*T\b/gi, 'JTT'],
    [/\bGB\s*\/\s*T\b/gi, 'GB_T'],
    [/\bJTG\s*\/\s*T\b/gi, 'JTG_T'],
    [/\bJGJ\s*\/\s*T\b/gi, 'JGJ_T'],
    [/\bCJJ\s*\/\s*T\b/gi, 'CJJ_T'],
    [/\bJTG\b(?![\s_/]*T)/gi, 'JTG '],
    [/\bAQ\s*\/\s*T\b/gi, 'AQ_T'],
    [/\bGA\s*\/\s*T\b/gi, 'GA_T'],
  ]
  let out = rawQuery
  for (const [pattern, replacement] of fixes) {
    out = out.replace(pattern, replacement)
  }
  return out
}

const EXACT_IDENTIFIER_PATTERNS: RegExp[] = [
  // European/international standards: BS EN 1992-1-1:2004, EN 1990, …
  /\b(?:BS\s*\/?\s*EN|EN|ISO|ASTM|DIN|JIS)\s+[A-Z]{0,2}\d{1,4}(?:\s*[-—–]\s*\d{1,4}){0,2}(?:\s*:\s*\d{4})?/gi,
  // Chinese standards: GB/T 50010-2010, JTG D60-2004, …
  /\b(?:JT\s*\/\s*T|GB\s*\/\s*T|JTG\s*\/\s*T|JGJ\s*\/\s*T|CJJ\s*\/\s*T|JTG|GB|JGJ|CJJ|JT|AQ|GA)\s+[A-Z]?\d{1,4}(?:\s*[-—–]\s*\d{1,4}){0,2}/gi,
  // Chapter markers: 第三十三回, 第5章.
  /第[一二三四五六七八九十百千\d]+[章节回]/g,
  // Model/version numbers: A36, V2.1, 1992-1-1 (surrounded by spaces/punct).
  /(?:^|[\s(])((?:[A-Z]{2,}\s*)?\d+(?:[.-]\d+)+)(?:[\s)]|$)/gi,
]

function extractIdentifierCandidates(rawQuery: string): string[] {
  const candidates = new Set<string>()
  const qNorm = normalizeAliasText(rawQuery)
  if (qNorm.length >= MIN_IDENTIFIER_LEN) candidates.add(rawQuery)
  for (const pat of EXACT_IDENTIFIER_PATTERNS) {
    for (const m of rawQuery.matchAll(pat)) {
      const unit = m[0].trim()
      const unitNorm = normalizeAliasText(unit)
      if (unit && unitNorm.length >= MIN_IDENTIFIER_LEN) candidates.add(unit)
    }
  }
  return [...candidates].sort((a, b) => {
    const diff = normalizeAliasText(b).length - normalizeAliasText(a).length
    return diff !== 0 ? diff : a < b ? -1 : 1
  })
}

/** Exact identifier match against doc_id/doc_title (bidirectional substring). */
function exactIdentifierMatch(
  conn: DatabaseSync,
  rawQuery: string,
  topK: number,
  docIds?: string[],
): Array<[string, string, string, number]> {
  const candidates = extractIdentifierCandidates(rawQuery)
  if (candidates.length === 0) return []

  const filter = docIds && docIds.length > 0 ? ` AND doc_id IN (${docIds.map(() => '?').join(',')})` : ''
  const params = docIds && docIds.length > 0 ? docIds : []
  const rows = conn.prepare(
    `SELECT doc_id, doc_title, source_file FROM docs WHERE is_active = 1${filter}`,
  ).all(...params) as Array<{ doc_id: string; doc_title: string; source_file: string }>

  const seenDocIds = new Set<string>()
  const matches: Array<{ docId: string; title: string; file: string; rank: [number, number, number, number] }> = []
  for (const candidate of candidates) {
    const qNorm = normalizeAliasText(candidate)
    if (qNorm.length < MIN_IDENTIFIER_LEN) continue
    for (const r of rows) {
      const docId = r.doc_id
      if (seenDocIds.has(docId)) continue
      if (!safeDocId(docId)) continue // result-set hygiene: never surface traversal ids
      const docIdNorm = normalizeAliasText(docId)
      const titleNorm = normalizeAliasText(r.doc_title)
      const idMatch = docIdNorm.length > 0 && (docIdNorm.includes(qNorm) || qNorm.includes(docIdNorm))
      const titleMatch = titleNorm.length > 0 && (titleNorm.includes(qNorm) || qNorm.includes(titleNorm))
      if (!idMatch && !titleMatch) continue
      if (idMatch && /^\d+$/.test(docIdNorm) && /[a-z]/.test(qNorm) && docIdNorm.length < qNorm.length) continue
      seenDocIds.add(docId)
      const lenDiff = idMatch
        ? Math.abs(docIdNorm.length - qNorm.length)
        : Math.abs(titleNorm.length - qNorm.length)
      const rank: [number, number, number, number] = [
        idMatch ? 0 : 1,
        -qNorm.length,
        lenDiff,
        -Math.max(docIdNorm.length, titleNorm.length),
      ]
      matches.push({ docId, title: r.doc_title, file: r.source_file, rank })
    }
  }
  matches.sort((a, b) => {
    const ar = a.rank
    const br = b.rank
    for (let i = 0; i < 4; i++) {
      const av = ar[i] ?? 0
      const bv = br[i] ?? 0
      if (av !== bv) return av - bv
    }
    return 0
  })
  return matches.slice(0, topK).map((m) => [m.docId, m.title, m.file, EXACT_MATCH_BOOST])
}

/**
 * Full-text window density (legacy packs without the line index).
 * Port of the Python formula: SET intersection of query ASCII tokens with
 * window ASCII tokens, plus CJK substring presence; short docs take
 * max(cjk, ascii); windows advance by `scanStep`.
 */
export function windowDensityScore(text: string, queryTokens: Set<string>, windowSize: number, scanStep: number): number {
  if (!text) return 0
  return windowDensityScoreLines(text.split('\n').map((l) => l.toLowerCase()), queryTokens, windowSize, scanStep)
}

/** Whole-text max(cjk, ascii) density (short-doc branch formula). */
function wholeTextDensity(lowerLines: string[], queryTokens: Set<string>): number {
  const window = lowerLines.join('\n')
  const windowTokens = new Set<string>()
  for (const m of window.matchAll(/[a-z]+/g)) windowTokens.add(m[0])
  const cjkMatched = [...queryTokens].filter((t) => window.includes(t)).length
  const asciiMatched = [...queryTokens].filter((t) => windowTokens.has(t)).length
  return Math.max(cjkMatched, asciiMatched)
}

/** Window density over pre-split lowercased lines (shared by both paths). */
function windowDensityScoreLines(
  lowerLines: string[],
  queryTokens: Set<string>,
  windowSize: number,
  scanStep: number,
): number {
  if (queryTokens.size === 0 || lowerLines.length === 0) return 0
  const asciiRe = /[a-z]+/g
  const cjkQuery = [...queryTokens].filter((t) => t.length >= 2 && !/^[\x00-\x7F]*$/.test(t))

  const scoreWindow = (start: number, end: number): number => {
    const asciiInWindow = new Set<string>()
    for (let i = start; i < end; i++) {
      for (const m of (lowerLines[i] ?? '').matchAll(asciiRe)) asciiInWindow.add(m[0])
    }
    let asciiMatched = 0
    for (const t of queryTokens) {
      if (asciiInWindow.has(t)) asciiMatched++
    }
    let cjkMatched = 0
    for (const t of cjkQuery) {
      for (let i = start; i < end; i++) {
        if ((lowerLines[i] ?? '').includes(t)) {
          cjkMatched++
          break
        }
      }
    }
    return asciiMatched + cjkMatched
  }

  if (lowerLines.length <= windowSize) {
    const window = lowerLines.join('\n')
    const windowTokens = new Set<string>()
    for (const m of window.matchAll(asciiRe)) windowTokens.add(m[0])
    let cjkMatched = 0
    for (const t of queryTokens) {
      if (window.includes(t)) cjkMatched++
    }
    let asciiMatched = 0
    for (const t of queryTokens) {
      if (windowTokens.has(t)) asciiMatched++
    }
    return Math.max(cjkMatched, asciiMatched)
  }
  let best = 0
  for (let start = 0; start <= lowerLines.length - windowSize; start += scanStep) {
    const matched = scoreWindow(start, start + windowSize)
    if (matched > best) best = matched
  }
  return best
}

/** Streaming density scan over line_text (reference path; O(lines)). Exported
 * for the equivalence regression test against the event-based index path. */
export function densityFromLineIndexStreaming(
  conn: DatabaseSync,
  docId: string,
  queryTokens: Set<string>,
  windowSize: number,
  scanStep: number,
): number {
  try {
    const cursor = conn.prepare(
      'SELECT line_number, text FROM line_text WHERE doc_id = ? ORDER BY line_number',
    ).iterate(docId) as Iterable<{ line_number: number; text: string }>
    const lines: string[] = []
    for (const row of cursor) lines.push((row.text ?? "").toLowerCase())
    // Short/long decision follows the CANONICAL line count (matching the
    // event path); the doc.md wrapper rows push raw line counts past 20.
    const lc = conn.prepare('SELECT line_count FROM docs WHERE doc_id = ?').get(docId) as
      { line_count: number } | undefined
    if (lc && lc.line_count > 0 && lc.line_count <= windowSize) {
      return wholeTextDensity(lines, queryTokens)
    }
    return windowDensityScoreLines(lines, queryTokens, windowSize, scanStep)
  } catch {
    return 0 // legacy pack without the line index
  }
}

/** Window density via line_fts hit events — cost O(hit lines), fully
 * decoupled from the document's total line count.
 *
 * A window [s, s+windowSize) covers token t iff t has a hit line l with
 * slot ∈ [l-windowSize, l-1]; with scanStep=5 and windowSize=20 each hit
 * line touches at most 4 window slots. We only inspect slots containing
 * ≥1 hit line (all other windows score 0).
 *
 * Tokens are restricted to pure [a-z]+ (the original window census extracts
 * words with `[a-z]+`, so digit/underscore tokens can never match a window —
 * counting them would flip rankings vs the legacy/streaming path).
 * MATCH is bounded per (token, doc) by the build-time rowid range, so memory
 * stays O(candidate hit lines), not O(corpus hit lines).
 */
/** Window density via line_fts hit events — cost O(hit lines), fully
 * decoupled from the document's total line count.
 *
 * A window [s, s+windowSize) covers token t iff t has a hit line l with
 * slot ∈ [l-windowSize, l-1]; with scanStep=5 and windowSize=20 each hit
 * line touches at most 4 window slots. We only inspect slots containing
 * ≥1 hit line (all other windows score 0).
 *
 * Tokens are restricted to pure [a-z]+ (the original window census extracts
 * words with `[a-z]+`), and line_fts stores each line's [a-z]+ word set, so
 * glued alnum tokens (GB50010-2010) expose their letter segments and
 * digit/underscore-only tokens never match — identical to the census.
 * The MATCH is scoped to candidate docs via a line_rowmap JOIN, so memory
 * stays O(candidate hit lines). An empty rowmap (stale/empty index) falls
 * back to the streaming scan per doc instead of silent zeros.
 */
export function densityScoresByIndex(
  conn: DatabaseSync,
  docIds: string[],
  queryTokens: Set<string>,
  windowSize: number,
  scanStep: number,
): Map<string, number> {
  const out = new Map(docIds.map((d) => [d, 0]))
  const tokens = [...queryTokens].filter((t) => /^[a-z]+$/.test(t))
  if (tokens.length === 0 || docIds.length === 0) return out

  let lineCounts: Array<{ doc_id: string; line_count: number }>
  try {
    const ph = docIds.map(() => '?').join(',')
    lineCounts = conn.prepare(
      `SELECT doc_id, line_count FROM docs WHERE doc_id IN (${ph})`,
    ).all(...docIds) as Array<{ doc_id: string; line_count: number }>
  } catch {
    return out
  }
  const lineCountByDoc = new Map(lineCounts.map((r) => [r.doc_id, r.line_count]))
  const maxLineStmt = conn.prepare('SELECT MAX(line_number) AS m FROM line_text WHERE doc_id = ?')
  const maxLine = maxLineStmt.get.bind(maxLineStmt)

  // Per-token hit lines scoped to the candidate docs (JOIN line_rowmap).
  const hitByDoc = new Map<string, Map<string, number[]>>() // docId -> token -> line numbers
  try {
    const ph = docIds.map(() => '?').join(',')
    const stmt = conn.prepare(`
      SELECT r.doc_id, r.line_number
      FROM line_fts JOIN line_rowmap r ON r.rowid = line_fts.rowid
      WHERE line_fts MATCH ? AND r.doc_id IN (${ph})
    `)
    const rowsFor = stmt.all.bind(stmt)
    for (const t of tokens) {
      const rows = rowsFor(`"${t.replaceAll('"', '""')}"`, ...docIds) as Array<{ doc_id: string; line_number: number }>
      for (const r of rows) {
        let byToken = hitByDoc.get(r.doc_id)
        if (!byToken) {
          byToken = new Map()
          hitByDoc.set(r.doc_id, byToken)
        }
        let lines = byToken.get(t)
        if (!lines) {
          lines = []
          byToken.set(t, lines)
        }
        lines.push(r.line_number)
      }
    }
  } catch {
    // Index unusable (missing/corrupt): streaming scan for every doc.
    for (const docId of docIds) {
      out.set(docId, densityFromLineIndexStreaming(conn, docId, queryTokens, windowSize, scanStep))
    }
    return out
  }

  for (const docId of docIds) {
    const totalLines = lineCountByDoc.get(docId) ?? 0
    // 短文档（canonical 行数 ≤ windowSize）：原版整文 max(cjk, ascii) 公式，
    // 对完整 ascii token 集（含数字/下划线）做子串计数。内联实现——传入
    // doc.md 全部行（行数恒 > windowSize）会误走长文档分支。
    if (totalLines > 0 && totalLines <= windowSize) {
      const lines: string[] = []
      try {
        const cursor = conn.prepare(
          'SELECT line_number, text FROM line_text WHERE doc_id = ? ORDER BY line_number',
        ).iterate(docId) as Iterable<{ line_number: number; text: string }>
        for (const row of cursor) lines.push((row.text ?? "").toLowerCase())
      } catch {
        continue
      }
      out.set(docId, wholeTextDensity(lines, queryTokens))
      continue
    }
    const byToken = hitByDoc.get(docId)
    if (!byToken) {
      // No hit lines AND no rowmap rows for this doc could mean a stale
      // index — the empty-rowmap guard below handles the global case; a
      // single doc missing from the rowmap is a partial-stale index.
      out.set(docId, densityFromLineIndexStreaming(conn, docId, queryTokens, windowSize, scanStep))
      continue
    }
    // 窗口槽上限基于 line_text 行号空间（= doc.md 行数）。
    let maxSlot = totalLines - windowSize
    try {
      const m = (maxLine(docId) as { m: number | null } | undefined)?.m
      if (typeof m === 'number' && m > 0) maxSlot = m - windowSize
    } catch {
      // fall through to canonical estimate
    }
    const coverage = new Map<number, number>()
    for (const [, lines] of byToken) {
      lines.sort((a, b) => a - b)
      const slots = new Set<number>()
      for (const l of lines) {
        const lo = Math.max(0, l - windowSize)
        const hi = Math.min(l - 1, maxSlot)
        if (lo > hi) continue
        for (let slot = Math.ceil(lo / scanStep) * scanStep; slot <= hi; slot += scanStep) {
          slots.add(slot)
        }
      }
      for (const slot of slots) {
        coverage.set(slot, (coverage.get(slot) ?? 0) + 1)
      }
    }
    let best = 0
    for (const v of coverage.values()) {
      if (v > best) best = v
    }
    out.set(docId, best)
  }
  return out
}

interface DocHit {
  docId: string
  title: string
  file: string
  score: number
}

/** Search doc_fts and return top-K documents (BM25 + exact + density rerank). */
function searchDocs(
  conn: DatabaseSync,
  rawQuery: string,
  opts: {
    topK: number
    docIds?: string[]
    windowDensity?: boolean
    matchTokens?: string[]
    packRoot: string
  },
): DocHit[] {
  const exact = exactIdentifierMatch(conn, rawQuery, opts.topK, opts.docIds)

  const tokens = ftsTokens(rawQuery)
  const searchTokens = opts.matchTokens && opts.matchTokens.length > 0 ? opts.matchTokens : tokens
  if (searchTokens.length === 0) return exact.map(([docId, title, file, score]) => ({ docId, title, file, score }))

  const matchExpr = searchTokens.slice(0, 64).map((t) => `"${t.replaceAll('"', '""')}"`).join(' OR ')
  // Candidate pool shrinks by the exact-match count and excludes those docs
  // (the original: fts_part = fts_results[:max(0, candidate_k - len(exact))]).
  const candidateK = opts.windowDensity === false ? opts.topK : opts.topK * 3
  const ftsLimit = Math.max(1, candidateK - exact.length)

  const filter = opts.docIds && opts.docIds.length > 0 ? ` AND d.doc_id IN (${opts.docIds.map(() => '?').join(',')})` : ''
  const params = opts.docIds && opts.docIds.length > 0 ? [...opts.docIds] : []
  const exactIds = new Set(exact.map((e) => e[0]))
  const excluded = exactIds.size > 0 ? ' AND d.doc_id NOT IN (' + [...exactIds].map(() => '?').join(',') + ')' : ''
  const exParams = exactIds.size > 0 ? [...exactIds] : []
  const rows = conn.prepare(`
    SELECT d.doc_id, d.doc_title, d.source_file, bm25(doc_fts, 10.0, 1.0) AS rank
    FROM doc_fts JOIN docs d ON d.doc_row_id = doc_fts.rowid
    WHERE doc_fts MATCH ? AND d.is_active = 1${filter}${excluded}
    ORDER BY rank LIMIT ?
  `).all(matchExpr, ...params, ...exParams, ftsLimit) as Array<{ doc_id: string; doc_title: string; source_file: string; rank: number }>

  // Normalize scores (negative, lower is better): divide by top1 abs.
  let merged: Array<[string, string, string, number]> = rows.map((r) => [r.doc_id, r.doc_title, r.source_file, r.rank])
  if (merged.length > 0) {
    const top1Abs = Math.abs(merged[0]?.[3] ?? 1) || 1
    merged = merged.map(([docId, title, file, score]) => [docId, title, file, score / top1Abs])
    // Category boost, then re-sort by weighted score (the original re-sorts too).
    merged = merged.map(([docId, title, file, score]) => [docId, title, file, score * (CATEGORY_BOOST[docCategory(file, docId)] ?? 1.0)])
    merged.sort((a, b) => (a[3] ?? 0) - (b[3] ?? 0))
  }

  // Window-density rerank: ASCII-token queries with results > 1 (the original
  // deliberately disables it for CJK queries — measured regression on CJK corpora).
  const asciiTokens = tokens.filter((t) => /^[\x00-\x7F]*$/.test(t))
  const asciiTokenCount = new Set(asciiTokens).size
  const useDensity = opts.windowDensity !== false
    && merged.length > 1
    && asciiTokenCount >= MIN_ASCII_TOKENS_FOR_WINDOW
  if (useDensity) {
    // The original passes ONLY ascii tokens into density scoring (CJK rerank
    // was measured to regress CJK corpora and is deliberately disabled).
    const queryTokens = new Set(tokens.filter((t) => /^[\x00-\x7F]*$/.test(t)))
    const scored: Array<[number, number, [string, string, string, number]]> = []
    const hasIndex = hasLineIndex(conn)
    let densities: Map<string, number>
    if (hasIndex) {
      densities = densityScoresByIndex(conn, merged.map((m) => m[0]), queryTokens, WINDOW_SIZE_DEFAULT, WINDOW_SCAN_STEP)
    } else {
      densities = new Map()
    }
    merged.forEach((item, bm25Rank) => {
      let density = 0
      if (hasIndex) {
        density = densities.get(item[0]) ?? 0
      } else {
        const body = getDocBody(item[0], opts.packRoot)
        if (body) {
          density = windowDensityScore(body, queryTokens, WINDOW_SIZE_DEFAULT, WINDOW_SCAN_STEP)
        }
      }
      scored.push([density, bm25Rank, item])
    })
    scored.sort((a, b) => b[0] - a[0] || a[1] - b[1])
    merged = scored.map(([, , item]) => item)
  }

  // Exact matches pinned first, deduped.
  const seen = new Set<string>()
  const out: DocHit[] = []
  for (const item of [...exact, ...merged]) {
    if (seen.has(item[0])) continue
    seen.add(item[0])
    out.push({ docId: item[0], title: item[1], file: item[2], score: item[3] })
    if (out.length >= opts.topK) break
  }
  return out
}

/** Reject path traversal in doc_id (mirrors read.ts resolveDocPath). */
function safeDocId(docId: string): boolean {
  if (!docId || docId.includes('/') || docId.includes('\\') || docId.includes('..')) return false
  return true
}

/** Read the original text from references/<doc_id>/doc.md (strip frontmatter). */
export function getDocBody(docId: string, packRoot: string): string {
  if (!safeDocId(docId)) return ''
  const refPath = join(packRoot, 'references', docId, 'doc.md')
  try {
    // Symlink containment: the REAL target must stay under references/;
    // read the verified real path (closes the check-then-read window).
    const real = realpathSync(refPath)
    const refsRoot = realpathSync(join(packRoot, 'references'))
    if (relative(refsRoot, real).startsWith('..')) return ''
    // FULL doc.md (frontmatter included): line numbers are the physical
    // doc.md lines, identical to the line_text index and kb_read.
    return readFileSync(real, 'utf8')
  } catch {
    return ''
  }
}

/** Find lines containing any token: sorted by hit count desc, line number asc. */
export function findMatchingLines(bodyText: string, tokens: string[], maxMatches = MAX_MATCH_LINES): Array<{ line: number; text: string }> {
  if (!bodyText || tokens.length === 0) return []
  const tokenLowers = tokens.filter(Boolean).map((t) => t.toLowerCase())
  const raw: Array<[number, number, string]> = []
  bodyText.split('\n').forEach((line, idx) => {
    const lineLower = line.toLowerCase()
    const hitCount = tokenLowers.reduce((acc, t) => acc + (lineLower.includes(t) ? 1 : 0), 0)
    if (hitCount > 0) raw.push([hitCount, idx + 1, line.replace(/\s+$/, '')])
  })
  raw.sort((a, b) => b[0] - a[0] || a[1] - b[1])
  return raw.slice(0, maxMatches).map(([, line, text]) => ({ line, text }))
}

/** Streamed line match over line_text. Never materializes the hit set:
 * keeps per-hit-count buckets of at most `maxMatches` rows (line-ascending,
 * so the first rows per bucket are the smallest line numbers — identical to
 * the old sort by (hitCount desc, line asc)) plus coverage flags.
 *
 * text_lower column detection is explicit (PRAGMA, O(1)): packs without it
 * (pre-text_lower builds that were not yet rebuilt) scan with
 * instr(lower(text), ?) and lowercase in JS — never a silent empty result
 * from a 'no such column' error. */
export function findMatchingLinesStream(
  conn: DatabaseSync,
  docId: string,
  tokens: string[],
  opts: { maxMatches?: number; queryLower?: string } = {},
): {
  matches: Array<{ line: number; text: string }>
  /** Lowercased tokens that occur on ≥1 line. */
  covered: Set<string>
  /** Whether any line contains the whole query (lowercased). */
  phraseHit: boolean
} {
  const active = tokens.filter(Boolean).map((t) => t.toLowerCase())
  const maxMatches = Math.max(1, opts.maxMatches ?? MAX_MATCH_LINES)
  const result = {
    matches: [] as Array<{ line: number; text: string }>,
    covered: new Set<string>(),
    phraseHit: false,
  }
  if (active.length === 0) return result

  let hasLowerCol = false
  try {
    const cols = conn.prepare('PRAGMA table_info(line_text)').all() as Array<{ name: string }>
    hasLowerCol = cols.some((c) => c.name === 'text_lower')
  } catch {
    return result // line_text missing (legacy pack) — caller falls back to files
  }
  const where = hasLowerCol
    ? active.map(() => 'instr(COALESCE(text_lower, lower(text)), ?) > 0').join(' OR ')
    : active.map(() => 'instr(lower(text), ?) > 0').join(' OR ')
  const projection = hasLowerCol ? 'line_number, text, text_lower' : 'line_number, text'
  let rows: Iterable<{ line_number: number; text: string; text_lower: string | null }>
  try {
    rows = conn.prepare(
      `SELECT ${projection} FROM line_text WHERE doc_id = ? AND (${where}) ORDER BY line_number`,
    ).iterate(docId, ...active) as unknown as Iterable<{ line_number: number; text: string; text_lower: string | null }>
  } catch {
    return result
  }
  // Per-hit-count buckets: bucket[h] holds the first maxMatches lines with
  // that hit count, in line order (the sort's tie-break).
  const buckets = new Map<number, Array<{ line: number; text: string }>>()
  const queryLower = opts.queryLower ? opts.queryLower.toLowerCase() : ''
  for (const row of rows) {
    const lineLower = hasLowerCol && row.text_lower != null ? row.text_lower : (row.text ?? '').toLowerCase()
    let hitCount = 0
    for (const t of active) {
      if (lineLower.includes(t)) {
        hitCount += 1
        result.covered.add(t)
      }
    }
    if (hitCount === 0) continue
    if (queryLower && lineLower.includes(queryLower)) result.phraseHit = true
    let bucket = buckets.get(hitCount)
    if (!bucket) {
      bucket = []
      buckets.set(hitCount, bucket)
    }
    if (bucket.length < maxMatches) bucket.push({ line: row.line_number, text: (row.text ?? '').replace(/\s+$/, '') })
  }
  const sorted = [...buckets.entries()].sort((a, b) => b[0] - a[0])
  result.matches = sorted.flatMap(([, bucket]) => bucket).slice(0, maxMatches)
  return result
}

/** Line-level matching via line_text substring scan (SQL-instr, C speed):
 * identical semantics to the legacy full-text scan (lowercased substring
 * containment per token), memory O(hit lines). One query per candidate doc. */
export function findMatchingLinesByText(
  conn: DatabaseSync,
  docId: string,
  tokens: string[],
  maxMatches = MAX_MATCH_LINES,
): Array<{ line: number; text: string }> {
  return findMatchingLinesStream(conn, docId, tokens, { maxMatches }).matches
}

function extractQueryUnits(rawQuery: string): { identifierUnits: string[]; contentUnits: string[] } {
  let text = rawQuery
  const identifierUnits: string[] = []
  for (const pat of EXACT_IDENTIFIER_PATTERNS) {
    for (const m of text.matchAll(pat)) {
      const unit = m[0].trim()
      if (unit && unit.length >= 2) identifierUnits.push(unit)
    }
    text = text.replace(pat, ' ')
  }
  const contentUnits: string[] = []
  for (const m of text.matchAll(/[\u4e00-\u9fff]+/g)) {
    if (m[0].length >= 2) contentUnits.push(m[0])
  }
  for (const m of text.matchAll(/[a-zA-Z0-9_]{2,}/g)) {
    contentUnits.push(m[0])
  }
  return { identifierUnits, contentUnits }
}

/** Whether any identifier unit matches a returned doc_id/title (normalized). */
function checkIdentifierHits(identifierUnits: string[], results: Array<{ docId: string; title: string }>): boolean {
  if (identifierUnits.length === 0 || results.length === 0) return false
  const normalizedUnits = identifierUnits.map(normalizeAliasText)
  for (const r of results) {
    const docIdNorm = normalizeAliasText(r.docId)
    const titleNorm = normalizeAliasText(r.title)
    for (const uNorm of normalizedUnits) {
      if (!uNorm) continue
      if (docIdNorm.includes(uNorm) || uNorm.includes(docIdNorm)) return true
      if (titleNorm.includes(uNorm) || uNorm.includes(titleNorm)) return true
    }
  }
  return false
}

/** OOV ratio: share of unique query tokens absent from the corpus doc_fts. */
function queryOovRatio(conn: DatabaseSync, tokens: string[]): number {
  const uniq = new Set(tokens.filter(Boolean).slice(0, 64))
  if (uniq.size === 0) return 0
  let present = 0
  for (const t of uniq) {
    try {
      const r = conn.prepare('SELECT 1 FROM doc_fts WHERE doc_fts MATCH ? LIMIT 1').get(`"${t.replaceAll('"', '""')}"`)
      if (r) present += 1
    } catch {
      // single-token syntax errors (pure punctuation) count as absent
    }
  }
  return 1 - present / uniq.size
}

/** Confidence score (0-1), port of _confidence_score — body-text variant
 * (legacy packs): token coverage and whole-phrase are literal lowercased
 * substring checks against the full body, exactly like the original. */
function confidenceFromBody(
  bm25Score: number,
  category: string,
  rawQuery: string,
  bodyText: string,
  rawTokens: string[],
  topMatches: Array<{ text?: string }>,
): number {
  const bm25Component = Math.min(Math.abs(bm25Score), 1.0)
  const maxBoost = Math.max(...Object.values(CATEGORY_BOOST))
  const catComponent = (CATEGORY_BOOST[category] ?? 1.0) / maxBoost

  const bodyLower = (bodyText ?? '').toLowerCase()
  let tokenCoverage = 0
  if (rawTokens.length > 0 && bodyText) {
    const covered = rawTokens.reduce((acc, t) => acc + (bodyLower.includes(t.toLowerCase()) ? 1 : 0), 0)
    tokenCoverage = covered / rawTokens.length
  }
  const phraseBonus = bodyLower.includes(rawQuery.toLowerCase()) ? 1 : 0

  const longTokens = rawTokens.filter((t) => t.length >= 3).map((t) => t.toLowerCase())
  let longCoverage = 1
  if (longTokens.length > 0 && topMatches.length > 0) {
    const topText = topMatches.map((m) => (m.text ?? '').toLowerCase()).join('\n')
    const coveredLong = longTokens.reduce((acc, t) => acc + (topText.includes(t) ? 1 : 0), 0)
    longCoverage = coveredLong / longTokens.length
  }

  return (
    0.3 * bm25Component
    + 0.2 * catComponent
    + 0.1 * tokenCoverage
    + 0.1 * phraseBonus
    + 0.3 * longCoverage
  )
}

/** Confidence score — summary variant (indexed packs). Token coverage and
 * whole-phrase are literal substring checks accumulated during the streamed
 * line scan (by construction every line holding any query token was seen,
 * so the flags are equivalent to checking the whole body — without
 * materializing the hit-line set). */
function confidenceFromLines(
  bm25Score: number,
  category: string,
  rawTokens: string[],
  covered: Set<string>,
  phraseHit: boolean,
  topMatches: Array<{ text?: string }>,
): number {
  const bm25Component = Math.min(Math.abs(bm25Score), 1.0)
  const maxBoost = Math.max(...Object.values(CATEGORY_BOOST))
  const catComponent = (CATEGORY_BOOST[category] ?? 1.0) / maxBoost

  let tokenCoverage = 0
  if (rawTokens.length > 0) {
    const coveredCount = rawTokens.reduce((acc, t) => acc + (covered.has(t.toLowerCase()) ? 1 : 0), 0)
    tokenCoverage = coveredCount / rawTokens.length
  }
  const phraseBonus = phraseHit ? 1 : 0

  const longTokens = rawTokens.filter((t) => t.length >= 3).map((t) => t.toLowerCase())
  let longCoverage = 1
  if (longTokens.length > 0 && topMatches.length > 0) {
    const topText = topMatches.map((m) => (m.text ?? '').toLowerCase()).join('\n')
    const coveredLong = longTokens.reduce((acc, t) => acc + (topText.includes(t) ? 1 : 0), 0)
    longCoverage = coveredLong / longTokens.length
  }

  return (
    0.3 * bm25Component
    + 0.2 * catComponent
    + 0.1 * tokenCoverage
    + 0.1 * phraseBonus
    + 0.3 * longCoverage
  )
}

function loadSynonyms(packRoot: string): Record<string, string[]> {
  try {
    const data = JSON.parse(readFileSync(join(packRoot, 'synonyms.json'), 'utf8')) as unknown
    if (typeof data !== 'object' || data === null || Array.isArray(data)) return {}
    const out: Record<string, string[]> = {}
    for (const [key, vals] of Object.entries(data as Record<string, unknown>)) {
      const list = Array.isArray(vals) ? vals : [vals]
      out[String(key).toLowerCase()] = list.map((v) => String(v).toLowerCase())
    }
    return out
  } catch {
    return {}
  }
}

/** Append synonyms for each token (dedup, keep order) — port of _expand_tokens. */
function expandTokens(tokens: string[], synonyms: Record<string, string[]>): string[] {
  const expanded = [...tokens]
  const seen = new Set(tokens)
  for (const t of tokens) {
    for (const syn of synonyms[t] ?? []) {
      if (syn && !seen.has(syn)) {
        seen.add(syn)
        expanded.push(syn)
      }
    }
  }
  return expanded
}

/** Run a query against a knowledge pack. A corrupt/missing/empty kb.sqlite
 * (tampered or half-deleted pack) returns a no_hits result with an `error`
 * field instead of throwing a raw sqlite exception — the model can read the
 * failure and react (mirrors kb_read's graceful degradation). */
export interface QueryResult {
  tool: 'kbtool'
  cmd: 'query'
  query: string
  status: 'high_confidence' | 'needs_verification' | 'no_hits'
  fts_match: string
  results: Array<{
    file: string
    doc_id: string
    title: string
    score: number
    matches: Array<{ line: number; text: string }>
  }>
  next_action: string
  oos_reason?: string
  /** Set when the pack database is unreadable (corrupt/missing). */
  error?: string
  /** Set when the pack predates the physical-doc.md line base (stale lines). */
  warning?: string
}

/** build_state.index_version of the current index layout (see constants.ts). */

/** A warning when the pack predates the physical-doc.md line base (its line
 * numbers are misaligned with doc.md until rebuilt). Absent build state
 * (Python-original packs) reads fine — those are served by the file path. */
function packIndexWarning(packRoot: string): string | undefined {
  try {
    const state = JSON.parse(readFileSync(join(packRoot, 'build_state.json'), 'utf8')) as { index_version?: number }
    if (typeof state.index_version !== 'number' || state.index_version < INDEX_VERSION) {
      return 'pack was built with an older index layout: line numbers are not doc.md physical lines; run kb_build to rebuild'
    }
  } catch {
    // no build state — legacy pack, fine
  }
  return undefined
}

export function runQuery(packRoot: string, rawQuery: string, opts: { limit?: number; docIds?: string[] } = {}): QueryResult {
  const indexWarning = packIndexWarning(packRoot)
  const run = (): QueryResult => {
  const topK = Math.max(1, Math.min(100, Math.floor(opts.limit ?? 10)))
  const docIds = opts.docIds && opts.docIds.length > 0 ? opts.docIds.slice(0, 200) : undefined
  const query = rawQuery.trim()

  const empty = (status: 'no_hits', nextAction: string, oosReason?: string): QueryResult => ({
    tool: 'kbtool',
    cmd: 'query',
    query,
    status,
    fts_match: '',
    results: [],
    next_action: nextAction,
    ...(oosReason ? { oos_reason: oosReason } : {}),
  })
  if (!query) return empty('no_hits', 'retry_broader_or_stop')

  let conn: DatabaseSync | null = null
  try {
    conn = new DatabaseSync(join(packRoot, 'kb.sqlite'), { readOnly: true })
    conn.exec('PRAGMA cache_size = -65536')
    conn.exec('PRAGMA mmap_size = 268435456')
    conn.exec('PRAGMA temp_store = MEMORY')
  } catch (error) {
    try {
      conn?.close()
    } catch {
      // already broken — nothing to close
    }
    return {
      tool: 'kbtool',
      cmd: 'query',
      query,
      status: 'no_hits',
      fts_match: '',
      results: [],
      next_action: 'verify_pack_integrity_or_rebuild',
      error: `kb.sqlite unreadable: ${(error as Error).message}`,
    }
  }
  try {
    const normalizedQuery = rewriteStdNumbers(query)
    let tokens: string[]
    let expandedTokens: string[]
    let searchResults: DocHit[]
    try {
      tokens = ftsTokens(normalizedQuery)
      expandedTokens = expandTokens(tokens, loadSynonyms(packRoot))
      // The rewritten + synonym-expanded tokens drive the actual FTS search
      // (the original passes them as match_tokens); fts_match reports them too.
      searchResults = searchDocs(conn, query, { topK, packRoot, matchTokens: expandedTokens, ...(docIds ? { docIds } : {}) })
    } catch (error) {
      return {
        tool: 'kbtool',
        cmd: 'query',
        query,
        status: 'no_hits',
        fts_match: '',
        results: [],
        next_action: 'verify_pack_integrity_or_rebuild',
        error: `kb.sqlite unusable: ${(error as Error).message}`,
      }
    }
    if (searchResults.length === 0) return empty('no_hits', 'retry_broader_or_stop')
    const matchExpr = tokens.slice(0, 64).map((t) => `"${t.replaceAll('"', '""')}"`).join(' OR ')
    const rawTokens = ftsTokens(query)
    const allLineTokens = [...new Set([...tokens, ...rawTokens])]

    // Out-of-domain gate runs BEFORE line matching, so out-of-scope queries
    // never pay the (cheap, but non-zero) line-scan cost.
    const { identifierUnits } = extractQueryUnits(query)
    const idHits = identifierUnits.length > 0 ? checkIdentifierHits(identifierUnits, searchResults) : false
    let isOutOfScope = false
    let oosReason = ''
    if (identifierUnits.length > 0 && !idHits) {
      isOutOfScope = true
      oosReason = 'identifier_missed'
    } else if (idHits) {
      isOutOfScope = false
    } else {
      const oov = queryOovRatio(conn, rawTokens)
      if (oov >= OOS_OOV_RATIO) {
        isOutOfScope = true
        oosReason = `high_oov_${oov.toFixed(2)}`
      }
    }
    if (isOutOfScope) return empty('no_hits', 'out_of_scope', oosReason)

    // Line matching: only the first candidates (all of them when ≤5, which
    // is what the payload can show anyway) are scanned — streamed, so the
    // hit set is never materialized. Non-scanned candidates carry empty
    // matches.
    const LINE_SCAN_DOC_LIMIT = 5
    const useIndex = hasLineIndex(conn)
    const queryLower = query.toLowerCase()
    let results: Array<{
      file: string
      doc_id: string
      title: string
      score: number
      matches: Array<{ line: number; text: string }>
    }> = []
    let topScan: { covered: Set<string>; phraseHit: boolean; matches: Array<{ line: number; text: string }> } | null = null
    for (let i = 0; i < searchResults.length; i++) {
      const r = searchResults[i]!
      let matches: Array<{ line: number; text: string }> = []
      if (i < LINE_SCAN_DOC_LIMIT) {
        if (useIndex) {
          const scan = findMatchingLinesStream(conn, r.docId, allLineTokens, { queryLower })
          matches = scan.matches
          if (i === 0) topScan = scan
        } else {
          matches = findMatchingLines(getDocBody(r.docId, packRoot), allLineTokens)
        }
      }
      results.push({ file: r.file, doc_id: r.docId, title: r.title, score: r.score, matches })
    }

    const top = results[0]
    if (!top) return empty('no_hits', 'retry_broader_or_stop')
    const topCat = docCategory(top.file, top.doc_id)
    const confidence = useIndex && topScan
      ? confidenceFromLines(top.score, topCat, tokens, topScan.covered, topScan.phraseHit, top.matches)
      : confidenceFromBody(top.score, topCat, query, getDocBody(top.doc_id, packRoot), tokens, top.matches)
    const status = confidence >= MIN_CONFIDENCE_HIGH && (topCat === 'standard' || topCat === 'method')
      ? 'high_confidence'
      : 'needs_verification'

    // The stale-index warning applies only when the INDEXED path serves this
    // query (file-fallback line numbers are physical doc.md lines — correct).
    return {
      tool: 'kbtool',
      cmd: 'query',
      query,
      status,
      fts_match: matchExpr,
      results: results.slice(0, 5),
      next_action: 'read_file_at_lines',
      ...(indexWarning && useIndex ? { warning: indexWarning } : {}),
    }
  } finally {
    conn.close()
  }
  }
  return run()
}
