/**
 * Generated SKILL.md — a zero-script DSH skill: pure instructions + pack
 * data. Retrieval happens through the plugin's kb_query / kb_read tools, so
 * the generated skill ships NO scripts, NO python, NO wrappers.
 *
 * Line numbers are INTERNAL locators: the model uses them to drive
 * kb_read (around/jump), but answers cite SECTIONS (heading names), never
 * raw line numbers — kb lines are meaningless to the reader and exact-line
 * chasing in huge documents is error-prone.
 *
 * @module @dsh-external/dsh-kb-sieve/skill-md
 */

export interface SkillMdOptions {
  skillName: string
  title: string
  docCount: number
  /** Absolute path of the generated pack (skill bundle dir). */
  packDir: string
}

/** Render the generated skill's SKILL.md (DSH flavor, concise). */
export function renderGeneratedSkillMd(opts: SkillMdOptions): string {
  // The title is embedded in the description so the model can tell this
  // knowledge base apart from others in the skill catalog (multiple packs
  // ship one skill entry each).
  const desc =
    `检索并引用 ${opts.docCount} 份文档的原文（${opts.title}）。` +
    '当用户询问这些文档中的人物/事件/术语/数据/章节/定义/流程/关系时使用。' +
    '入口：调用 kb_query 工具检索，再用 kb_read 精读原文；' +
    '答案必须引用原文所在章节（references/ doc.md 中的章节标题），禁止凭记忆回答。' +
    '触发词：规范查询、条文出处、法规检索、standard lookup、规范原文。' +
    '不触发：与本文档集无关的通用知识、创意写作、常识性问题。'

  return [
    '---',
    `name: ${opts.skillName}`,
    `description: "${desc}"`,
    '---',
    '',
    `# ${opts.title}`,
    '',
    '> **核心原则**：查询是查询，生成是生成。所有结论必须来自检索到的原文，不要凭记忆补全。',
    '',
    '## 默认流程',
    '',
    `本知识库（pack）位于 \`${opts.packDir}\`。`,
    '',
    `1. **检索**：调用 \`kb_query\` 工具，参数 \`pack\` 传上面的路径、\`query\` 传问题关键词。`,
    '   - 返回 compact 摘要（doc_id + 行号 + 匹配行 + score + status）。',
    '   - status: `high_confidence` / `needs_verification` / `no_hits`。',
    '2. **精读原文**：从 query 结果取 `doc_id` 和 `line`，调用 \`kb_read\` 工具',
    '   （pack 同前、doc_id、around=行号、tokens=关键词）——自动定位到完整段落并标记命中。',
    '   - 行号只用于工具内部的精读定位，**不要**把它们当作文档真实页码。',
    '   - 需要文档地图时：`kb_read` 传 sections: true（标题行 + 行号区间）——用章节名定位。',
    '3. **引用**：回答引用原文时说明**所在章节**（如"位于「第 D21.3 节 Partition Identifiers」"），',
    '   不要向用户输出 kb 内部行号；未找到证据就明确说未找到。',
    '',
    '## 失败处理',
    '',
    '| 场景 | 识别信号 | 处理动作 |',
    '|---|---|---|',
    '| kb_query 报错 | 返回 error 或 pack 路径无效 | 检查 `kb.sqlite` 与 `references/` 是否存在；缺失则告知用户"知识库文件缺失"，否则重试一次 |',
    '| 连续 2 轮 query 无命中 | status 均为 `no_hits` | **停止**：向用户报告"未找到相关证据"，不编造答案 |',
    '| 大文档定位困难 | sections 截断（truncated）或 around 返回空 | 先用 sections 看章节名与行号区间，按**章节名**（而非具体行号）定位后 around 精读 |',
    '| 准备给出最终答案前 | 已完成 query/read | **检查点**：确认每个结论都有对应的 doc.md 原文引用（章节名）；未引用则回到 query/read 补证据 |',
    '',
    '## 推理链查询',
    '',
    '多跳问题（A→B→C→答案）禁止一次性查询所有关键词：每轮只查 1-2 个环节的关键词，',
    '从命中行提取新实体名作为下一轮查询词，直到确认每一跳；某一轮无命中就换关键词重查。',
    '',
    '## 文档清单',
    '',
    `全部文档的 doc_id/标题/路径见 pack 根目录的 \`manifest.json\`。`,
    '查看单文档章节地图：`kb_read`（doc_id、sections: true）。',
    '',
    '## 反模式（禁止）',
    '',
    '- 凭记忆或外部知识回答规范问题。',
    '- 只看 kb_query 的 compact 摘要就下结论，不精读原文。',
    '- 绕过 kb_read 直接猜测原文内容。',
    '- 向用户输出 kb 内部行号（如"L3733-3734"或"第 435301 行"）——行号是内部定位用的虚拟行号，引用一律用章节名。',
    '- 对 `no_hits` 或低相关查询编造答案；必须明确说"未找到相关证据"。',
    '',
  ].join('\n')
}
