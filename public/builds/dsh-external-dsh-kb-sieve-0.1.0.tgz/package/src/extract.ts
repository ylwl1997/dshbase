/**
 * Document extraction — faithful port of the Python `extract.py`.
 *
 * `.md` verbatim; `.txt`/`.pdf` text gets heading inference (underline,
 * Chapter/第X章, numbered, short-line heuristics); `.docx` parses OOXML
 * `w:p`/`w:t` paragraphs with Heading1-6 styles (zip via fflate); `.pdf`
 * requires the system `pdftotext` (poppler-utils), mirroring the original.
 *
 * @module @dsh-external/dsh-kb-sieve/extract
 */

import { readFile } from 'node:fs/promises'
import { readFileSync } from 'node:fs'
import { unzipSync } from 'fflate'

export class BuildError extends Error {}

/** Decode XML entities in docx w:t text (&amp; &lt; &gt; &quot; &apos; + numeric). */
function decodeXmlEntities(text: string): string {
  return text
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .replaceAll('&apos;', "'")
    .replaceAll('&amp;', '&')
    .replace(/&#x([0-9a-fA-F]+);/g, (_m, hex: string) => String.fromCodePoint(Number.parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_m, dec: string) => String.fromCodePoint(Number.parseInt(dec, 10)))
}

/**
 * Detect text encoding by fatal-decode cascade: utf-8-sig → utf-8 → gb18030 →
 * cp1252 → latin-1 (TextDecoder is non-fatal by default, so each step must
 * pass `fatal: true` or the cascade would silently accept mojibake).
 */
export function detectAndDecode(data: Uint8Array): string {
  // utf-8-sig: strip BOM, then require a clean UTF-8 decode.
  if (data.length >= 3 && data[0] === 0xEF && data[1] === 0xBB && data[2] === 0xBF) {
    return new TextDecoder('utf-8', { fatal: true }).decode(data.subarray(3))
  }
  const attempts: Array<[string, string]> = [
    ['utf-8', 'utf-8'],
    ['gb18030', 'gb18030'],
    ['cp1252', 'windows-1252'],
  ]
  for (const [, label] of attempts) {
    try {
      return new TextDecoder(label, { fatal: true }).decode(data)
    } catch {
      // try next
    }
  }
  // latin-1: any byte sequence is valid; use Buffer for the 1:1 byte→char map.
  return Buffer.from(data).toString('latin1')
}

async function readText(path: string): Promise<string> {
  const data = await readFile(path)
  return detectAndDecode(data)
}

/** Extract (level | null, text) paragraphs from a DOCX via OOXML. */
function docxParagraphs(data: Uint8Array): Array<[number | null, string]> {
  const files = unzipSync(data)
  const entry = files['word/document.xml']
  if (!entry) throw new BuildError('DOCX has no word/document.xml')
  const xml = new TextDecoder().decode(entry)

  const paras: Array<[number | null, string]> = []
  // Split into <w:p ...>...</w:p> blocks (paragraphs).
  const pRe = /<w:p\b[^>]*>([\s\S]*?)<\/w:p>/g
  const pStyleRe = /<w:pStyle\b[^>]*w:val="([^"]+)"/
  const tRe = /<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g
  const headingLevel = (style: string): number | null => {
    const m = /^Heading(\d)$/.exec(style) ?? /^标题\s*(\d)$/.exec(style)
    return m ? Number(m[1]) : null
  }
  for (const pm of xml.matchAll(pRe)) {
    const block = pm[1] ?? ''
    const styleM = pStyleRe.exec(block)
    const level = styleM ? headingLevel(styleM[1] ?? '') : null
    let text = ''
    for (const tm of block.matchAll(tRe)) {
      text += decodeXmlEntities(tm[1] ?? '')
    }
    if (text.trim().length > 0) paras.push([level, text.trim()])
  }
  return paras
}

function extractDocxToMarkdown(path: string): string {
  const data = readFileSync(path)
  const paras = docxParagraphs(data)
  if (paras.length === 0) {
    throw new BuildError(`Failed to extract DOCX paragraphs: ${path}. Try converting DOCX → MD/TXT first.`)
  }
  const out: string[] = []
  for (const [level, text] of paras) {
    if (level !== null) {
      out.push('#'.repeat(Math.max(1, Math.min(6, level))) + ' ' + text)
    } else {
      out.push(text)
    }
  }
  return out.join('\n\n').trim() + '\n'
}

/** Infer markdown headings from plain text (underline + short-line/numbered heuristics). */
export function inferTextHeadingsToMarkdown(text: string): string {
  const lines = text.split('\n').map((ln) => ln.replace(/\s+$/, ''))

  // Pass 1: underline headings (=== → H1, --- → H2).
  const out: string[] = []
  for (const ln of lines) {
    const s = ln.trim()
    if (!s) {
      out.push('')
      continue
    }
    if (/^={3,}$/.test(s) && out.length > 0) {
      const prev = (out.pop() ?? '').trim()
      out.push('# ' + prev)
      continue
    }
    if (/^-{3,}$/.test(s) && out.length > 0) {
      const prev = (out.pop() ?? '').trim()
      out.push('## ' + prev)
      continue
    }
    out.push(ln)
  }

  // Pass 2: short-line heuristic + numbered/chapter patterns.
  const result: string[] = []
  for (let i = 0; i < out.length; i++) {
    const ln = out[i] ?? ''
    const s = ln.trim()
    if (!s || s.startsWith('#')) {
      result.push(ln)
      continue
    }
    const prevBlank = i === 0 || !(out[i - 1] ?? '').trim()
    const nextBlank = i === out.length - 1 || !(out[i + 1] ?? '').trim()
    if (prevBlank && nextBlank) {
      if (/^Chapter\s+/i.test(s)) {
        result.push('# ' + s)
        continue
      }
      if (/^第[一二三四五六七八九十百千万\d]+[章节篇部]/.test(s)) {
        result.push('# ' + s)
        continue
      }
      const numM = /^(\d+(?:\.\d+)+)\s+\S/.exec(s)
      if (numM) {
        const depth = (numM[1] ?? '1').split('.').length
        result.push('#'.repeat(Math.min(depth, 6)) + ' ' + s)
        continue
      }
      if (s.length < 60) {
        if (/^[-*•·]\s/.test(s)) {
          result.push(ln)
          continue
        }
        if (/^\d+\.\s/.test(s) && !/^\d+\.\d+/.test(s)) {
          result.push(ln)
          continue
        }
        result.push('### ' + s)
        continue
      }
    }
    result.push(ln)
  }

  let md = result.join('\n')
  if (!md.endsWith('\n')) md += '\n'
  return md
}

/** Extract PDF text via system `pdftotext -layout` (poppler-utils), mirroring the original. */
async function extractPdfToText(path: string): Promise<string> {
  const { execFile } = await import('node:child_process')
  const { promisify } = await import('node:util')
  const execFileP = promisify(execFile)
  try {
    const { stdout } = await execFileP('pdftotext', ['-layout', path, '-'], {
      timeout: 120_000,
      maxBuffer: 256 * 1024 * 1024,
    })
    return stdout
  } catch {
    throw new BuildError(
      `PDF extraction requires 'pdftotext' (poppler-utils) on PATH for ${path}. ` +
      'Install it, or convert the PDF to TXT/MD first.',
    )
  }
}

/** Extract any supported input to markdown. */
export async function extractToMarkdown(path: string): Promise<string> {
  const suffix = path.toLowerCase().match(/\.[^.]+$/)?.[0] ?? ''
  if (suffix === '.md') return readText(path)
  if (suffix === '.txt') return inferTextHeadingsToMarkdown(await readText(path))
  if (suffix === '.docx') return extractDocxToMarkdown(path)
  if (suffix === '.pdf') return inferTextHeadingsToMarkdown(await extractPdfToText(path))
  throw new BuildError(`Unsupported input type: ${path} (supported: .md .txt .docx .pdf)`)
}
